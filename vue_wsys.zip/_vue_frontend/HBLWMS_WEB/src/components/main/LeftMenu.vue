<template>
  <div id="leftMenu">
    <v-list
      nav
      dense
      style="background:#e7dcdc;"
    >
      <v-list-item
        v-for="(menu, i) in cards"
        :key="i"
        link
        @mousedown="goToMenu(menu.code)"
        style="border:1px solid; background: linear-gradient(rgb(241 202 178), rgb(211 139 51));"
        
      >
        <img :src="menu.icon" style="width:20%;" />
        <v-list-item-content >
          <v-list-item-title style="margin:10%; color:black; font-size:15px;" >{{menu.name}}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
      <!-- <v-divider></v-divider> -->
    </v-list>
  </div>
  
</template>
<script>
export default {
  name: 'LeftMenu',
  data () {
    return {
      drawer:true,

      cards:  [
        { code:'STANDARD', name:'기준정보', link: 'components/views/StandardView', icon:require('@/assets/icons/manual_location.png') },
        { code:'WEARING', name:'입고', link: 'components/views/Wearing', icon:require('@/assets/icons/warehouse.png') },
        { code:'RELEASE', name:'출고', link: 'components/views/Release', icon:require('@/assets/icons/shipped.png') },
        { code:'STOCKMOVE', name:'재고위치조정', link: 'components/views/StockMove', icon:require('@/assets/icons/search_location.png') },
        { code:'STOCKMGMT', name:'재고현황', link: 'components/views/StockMgmt', icon:require('@/assets/icons/search_item.png') },
        { code:'USERMGMT', name:'사용자관리', link: 'components/views/UserMgmt', icon:require('@/assets/icons/search_rate.png') },
        // { code:'RECEIPTSTTM', name:'', link: 'components/views/ReceiptSttm' },
        // { code:'RELEASECERT', name:'', link: 'components/views/ReleaseCert' },
        // { code:'BINMAN', name:'창고검색', link: 'components/views/BinMan' },
        // { code:'MONITORING', name:'모니터링', link: 'components/views/MntView' },
 

        //{ code:'testCode', name:' ', link: '', icon:require('@/assets/icons/user.png') },
        //{ code:'DATATABLE', name:'테이블', link: 'components/views/DataTable', icon:require('@/assets/icons/search_rate.png') },
      ],
    }
  },
  mount(){

  },
  methods: {
    goToMenu(menu) {
      console.log(menu);
      // console.log("=======1=======");
      this.$router.push(menu).catch(()=>{
      //   console.log("======2========");
         location.reload();//페이지가 이미 열려있을경우 reload
      });
    },    

    // goToMenu(menu){
    //   console.log("========1=====");
    //   this.$router.push(menu).then(() => {
    //     console.log("========2=====");
    //     //location.reload();
    //     this.$router.go(0);
    //   }).catch(() => {});    
    // }

    setFullScreen() {
        const element = document.documentElement;

            element.requestFullscreen();
    },

  },

}
</script>