<template>
  <div>
    <v-btn width="480" @click="openDialog">입력</v-btn>
    <!--
    <table style="border:1px solid black">
      <thead >
        <tr style="border:1px solid black">
          <th style="border:1px solid black">품번</th>
          <th style="border:1px solid black">규격</th>
          <th style="border:1px solid black">상세사양</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id">
          <td style="border:1px solid black">{{ item.bin_code }}, </td>
          <td style="border:1px solid black">{{ item.specification }}, </td>
          <td style="border:1px solid black">{{ item.detail_info }}</td>
        </tr>
      </tbody>
    </table>
    //-->

    <v-data-table
      :headers="headers"
      :items="items"
      class="elevation-1"
      show-select
      item-key="id"
      height="100%"
      fixed-header
      dense
          
      :items-per-page="perPage"
      :footer-props="footerProps"
      :page.sync="page"
      :server-items-length="dataCounts"
      :options.sync="options"
    >
    </v-data-table>

    <!--
    <v-dialog v-if="showDialog" v-model="showDialog" row justify-center max-width="480" @close="showDialog = false" >
      <v-card>
        <h3>이름, 전화, 주소를 입력하세요.</h3>
      </v-card>
      <v-card>
        <input type="text" placeholder="이름">
      </v-card>
      <v-card>
        <input type="text" placeholder="전화번호">
      </v-card>
      <v-card>
        <input type="text" placeholder="주소">
      </v-card>
      <v-btn color="blue darken-1" text @click="close">취소</v-btn>
      <v-btn @click="[showDialog = false],[save]">저장</v-btn>
    </v-dialog>
    //-->
    
    <v-dialog v-if="showDialog" v-model="showDialog" row justify-center max-width="480" @close="closeDialog" >
      <v-card>
        <v-card-title >
          <span  class="headline" style="text-align:left;width:100%;align:center;">{{ formTitle }}</span>
        </v-card-title>
        <v-card-subtitle>
          <span  class="headline"  style="text-align:left;width:100%;align:center;color:blue;" >{{ subTitle }}</span>
        </v-card-subtitle>

        <v-card-text >
          <v-container>
            <v-row dense>
              <v-col cols="1" sm="1" md="7" >
                <v-text-field v-model="editedItem.name" label="품번" dense></v-text-field>
              </v-col>
            </v-row>
            <v-row dense>
              <v-col cols="1" sm="1" md="5" >
                <v-text-field v-model="editedItem.phone" label="규격" dense></v-text-field>
              </v-col>
            </v-row>
            <v-row dense>
              <v-col cols="1" sm="1" md="12" >
                <v-text-field v-model="editedItem.address" label="상세사양" dense></v-text-field>
              </v-col>
            </v-row>
          </v-container>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="closeDialog">취소</v-btn>
          <v-btn color="blue darken-1" text @click="save">저장</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

  </div>
</template>

<script>
import axios from 'axios'


export default {
  components: {
    
  },  
  data () {
    return {
      headers: [
            { value:'item_code', text:'품번', width:'15%', align:'start', sortable: true, },
            { value:'item_name', text:'품명', width:'15%', align:'start', sortable: true, },
            { value:'specification', text:'규격', width:'20%', align:'start', sortable: true, },
            { value:'detail_info', text:'상세사양', width:'15%', align:'start', sortable: true, },
            { value:'his_quan', text:'수량', width:'10%', align:'start', sortable: true, },
            { value:'bin_code', text:'위치정보', width:'10%', align:'start', sortable: true, },
            { value:'his_date', text:'입고날짜', width:'15%', align:'start', sortable: true, },
            // { value:'last_in_date', text:'최근입고날짜', width:'25%', align:'start', sortable: true, },
        ],

      items: [],
      showDialog: false,
      formTitle: ' 입고 입력',
      subTitle: '_______________________________________',
      editedItem: {
        name: '',
        phone: '',
        address: ''
      },
      dataCounts:0,
      perPage:10,
      page:1,
      footerProps: { 'items-per-page-options': [10, 20, 30, 40, 50, 100 -1] },
      options:{},

    }
  },
  mounted () {
    this.getDatas();
  },
  watch:{
    options(val) {
        var curPage = val.page;
        var itemsPerPage = val.itemsPerPage;
        if(itemsPerPage!=null && itemsPerPage==-1) {
            itemsPerPage = 100000000;
        }
        this.page = curPage;
        this.perPage = itemsPerPage;
        this.getDatas();
     },
  },
  methods: {
    getDatas(){
      var url = 'https://api.hblwms.co.kr/stock.do?method=readLocationHistory&uid_company=101000002025';
      var start = (this.page-1) * this.perPage;
        var limit = this.perPage;
        var obj = {
          uid_company:this.$store.getters.getUidCompany,
          start:start,
          limit:limit,
          gubun:'IN',
          apiType:'ALL',
          orderBy:'history.his_date desc'
        }

        var params = '';
        for(var key in obj) {
          params += '&' + key + '=' + obj[key]
        }

        if(this.params!=null) {
            for(var k in this.params) {
                params += '&' + k + '=' + this.params[k]
                console.log(k + '=' + this.params[k]);
            }
        }
        url += params;        
    // axios.get('https://api.hblwms.co.kr/stock.do?method=readLocationHistory&uid_company=101000002025&start=0&limit=100&gubun=IN&apiType=ALL&orderBy=history.his_date desc&item_code=x')
    //   .then(response => {
    //     console.log(response.data.datas)
    //     this.items = response.data.datas
    //   })
    //   .catch(error => {
    //     console.log(error)
    //   })

    // fetch('https://api.hblwms.co.kr/stock.do?method=readLocationHistory&uid_company=101000002025&start=0&limit=100&gubun=IN&apiType=ALL&orderBy=history.his_date desc&item_code=x')
    //   .then(response => response.json())
    //   .then(data => {
    //     this.items = data.datas
    //   })
    //   .catch(error => {
    //     console.log(error)
    //   })

    //fetch('https://api.hblwms.co.kr/stock.do?method=readLocationHistory&uid_company=101000002025&start=0&limit=100&gubun=IN&apiType=ALL&orderBy=history.his_date desc&item_code=')
    fetch(url)
      .then(res => res.json())
      .then(res => {
        //console.log(res)
        this.items = res.datas
        //console.log(this.items)
        const count = res.count;
        this.dataCounts = res.count;
      })
      .catch(error => {
        console.log(error)
      })    

    },
    openDialog () {
      this.showDialog = true
    },
    closeDialog() {
      this.showDialog = false
    },
    save() {
      const params = new URLSearchParams({
        name: this.editedItem.name,
        phone: this.editedItem.phone,
        address: this.editedItem.address
      })
      fetch(`/api/목록?${params}`, {
        method: 'GET'
      })
        .then(response => {
          console.log(response)
        })
        .catch(error => {
          console.log(error)
        })
      
      this.closeDialog(); // //this.showDialog = false
    }
  }

}
</script>
