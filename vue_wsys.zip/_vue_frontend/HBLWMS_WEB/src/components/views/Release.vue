<template>
    <div>
        <v-toolbar style="background:#cad9e5;">
            <v-row>
                <v-btn
                    tile
                    :style="{
                        backgroundColor: this.chgTable ? 'white' : '#1976D2',
                        color: this.chgTable ? 'gray' : 'white',
                      }" 
                    color=""
                    style="margin-right:1%;"
                    @click="initSort"
                    @mousedown="resetAddForm"
                    
                >
                    <v-icon left>
                        mdi-magnify
                    </v-icon>
                    출고검색
                </v-btn>
                <v-btn
                    tile
                    :style="{
                        backgroundColor: this.chgTable ? '#1976D2' : 'white',
                        color: chgTable ? 'white' : 'gray',
                      }" 
                    color=""
                    style="margin-right:1%;"
                    @click="initSort2"
                    @mousedown="resetAddForm"
                >
                    <v-icon left>
                        mdi-magnify
                    </v-icon>
                    재고검색
                </v-btn>
                <v-btn
                    tile
                    color="primary"
                    style="margin-right:1%;"
                    @click="dialog_release=true"
                    v-bind:disabled="this.cancelDisabled==false"
                    @mousedown="resetAddForm"
                >
                    <v-icon left>
                        mdi-plus-circle
                    </v-icon>
                    출고
                </v-btn>
                <!-- :disabled="cancelDisabled" -->
                <v-btn  v-if="this.chgTable=== true"
                    tile
                    color="error"
                    style="margin-right:1%;"
                    @click="dialogCancel=true"
                    v-bind:disabled="this.cancelDisabled==true"
                >
                    <v-icon left>
                        mdi-minus-circle
                    </v-icon>
                    출고취소
                </v-btn>
                <v-spacer></v-spacer>
                <v-btn
                    tile
                    color="success"
                    style="margin-right:1%;"
                    @click="releaseExcelUpload"
                >
                    <v-icon left>
                        mdi-upload
                    </v-icon>
                    업로드
                </v-btn>
                <v-btn
                    tile
                    color="primary"
                    style="margin-right:1%;"
                    @click="releaseExcelDownload"
                >
                    <v-icon left>
                        mdi-download
                    </v-icon>
                    출고내역
                </v-btn>
                <v-btn
                    tile
                    color="error"
                    style="margin-right:1%;"
                    @click="releaseExcelTemplate"
                >
                    <v-icon left>
                        mdi-file-excel
                    </v-icon>
                    템플릿
                </v-btn>
                <!-- <v-btn
                    tile
                    color="success"
                    style="margin-right:1%;"
                >
                    <v-icon left>
                        mdi-pencil
                    </v-icon>
                    수정
                </v-btn>
                <v-btn
                    tile
                    color="error"
                    style="margin-right:1%;"
                >
                    <v-icon left>
                        mdi-delete-circle
                    </v-icon>
                    삭제
                </v-btn> -->
            </v-row>
        </v-toolbar>
        <v-toolbar style="background:#cad9e5;height:50px;">
            <v-row>
                <div v-if="this.chgTable=== true" style="text-align:center;margin-right:1%; width:100%; border:0px solid gray; color:black; background:#cad9e5;">
                    <v-icon left style="fontSize:0px;">
                        mdi-application-outline
                    </v-icon>
                    출 고 리 스 트 &nbsp;
                </div>
                <div v-else style="text-align:center;margin-right:1%; width:100%; border:0px solid gray; color:black; background:#cad9e5;">
                    <v-icon left style="fontSize:0px;">
                        mdi-application-outline
                    </v-icon>
                    재 고 리 스 트 &nbsp;
                </div>
                <v-spacer></v-spacer>
            </v-row>
        </v-toolbar>
        <v-toolbar style="background:#cad9e5;">
            <v-toolbar-items style="margin-right:1%; margin-top:3%;" >
                <v-text-field v-if="this.chgTable=== true"
                    v-model="lot_code"
                    id="wearing-item_code"
                    label="LOT번호"
                    clearable
                    v-on:lot_code_update="onTextChangne2('lotno', $event)"
                    @change="value => onTextChangne('lotno', value)"
                    @input="onTextChangne2('lotno', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                    ref="lotno_val"
                ></v-text-field>

            </v-toolbar-items>
            <v-toolbar-items
                style="margin-right:1%; margin-top:3%;"
            >
                <v-text-field v-if="this.chgTable=== true"
                    v-model="i_code"
                    id="wearing-item_code"
                    label="품번"
                    clearable
                    @change="value => onTextChangne('item_code', value)"
                    @input="onTextChangne2('item_code', $event)"
                    
                    @keyup="getDatas"
                    v-on:i_code_update="onTextChangne2('item_code', $event)"
                    @keypress="disabledSelectAll"
                    @keydown="disabledSelectAll"
                ></v-text-field>
                <v-text-field v-if="chgTable=== false"
                    v-model="i_code"
                    id="wearing-item_code"
                    label="품번"
                    clearable
                    @change="value => onTextChangne('item_code', value)"
                    @input="onTextChangne2('item_code', $event)"
                    @keyup="getDatas2"
                    @keydown="disabledSelectAll"
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items
                style="margin-right:1%; margin-top:3%;"
            >
                <v-text-field v-if="chgTable=== true"
                    id="wearing-item_name"
                    label="품명"
                    clearable
                    @change="value => onTextChangne('item_name', value)"
                    @input="onTextChangne2('item_name', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                ></v-text-field>
                <v-text-field v-if="this.chgTable=== false"
                    id="wearing-item_name"
                    label="품명"
                    clearable
                    @change="value => onTextChangne('item_name', value)"
                    @input="onTextChangne2('item_name', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items  v-if="this.chgTable=== true"
                style="margin-right:1%; margin-top:3%;"
            >
                <v-text-field  v-if="this.chgTable=== true"
                    id="wearing-bin_code"
                    label="위치정보"
                    clearable
                    @change="value => onTextChangne('bin_code', value)"
                    @input="onTextChangne('bin_code', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items style="margin-right:1%; margin-top:3%;"  v-if="this.chgTable=== true">
                <v-menu
                    v-model="release_date_menu"
                    :close-on-content-click="false"
                    :nudge-right="40"
                    transition="scale-transition"
                    offset-y
                    min-width="auto"
                >
                    <template v-slot:activator="{ on, attrs }">
                        <v-text-field
                            v-model="date_range"
                            label="출고날짜"
                            readonly
                            v-bind="attrs"
                            v-on="on"
                            :append-outer-icon="'mdi-refresh'"
                            @click:append-outer="refreshDateRange"
                            @mousedown="disabledSelectAll"
                        ></v-text-field>
                    </template>
                    <v-date-picker
                        v-model="start_date"
                        @input="input_start"
                        locale="ko-KR"
                    ></v-date-picker>
                    <v-date-picker
                        v-model="end_date"
                        @input="input_end"
                        locale="ko-KR"
                    ></v-date-picker>
                </v-menu>
            </v-toolbar-items>
        </v-toolbar>
        <v-data-table  v-if="this.chgTable===true"
            v-model="selected"
            ref="dataTable"
            :headers="headers"
            :items="datas"
            class="elevation-1"
            show-select
            item-key="id"
            @click:col.0="onClickcol"
            @click:row="onClickRow"
            height="100%"
            fixed-header
            dense
                
            :items-per-page="perPage"
            :footer-props="footerProps"
            :page.sync="page"
            :server-items-length="dataCounts"
            :options.sync="options"
        >

        </v-data-table>
        <v-data-table  v-if="this.chgTable===false"
            v-model="selected"
            ref="dataTable"
            :headers="headers2"
            :items="datas"
            class="elevation-1"
            show-select
            item-key="id"
            @click:col.0="onClickcol"
            @click:row="onClickRow2"
            height="100%"
            fixed-header
            dense
                
            :items-per-page="perPage"
            :footer-props="footerProps"
            :page.sync="page"
            :server-items-length="dataCounts"
            :options.sync="options"
        >

        </v-data-table>


        <v-overlay :value="overlay">
            <v-progress-circular
                indeterminate
                size="64"
            ></v-progress-circular>
        </v-overlay>

        <v-dialog
            v-model="dialog_release"
            width='80%'
            height="45%"
            max-width="1200px"
            style="height: 45%;"
            scrollable
        >
            <div style="width:100%; height:100%; display:flex; background:white;">
                <div id="form" style="width:70%; height:680px;">
                    <v-card>
                        <v-card-title>
                            <span class="text-h4">출고</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                    <v-col cols="12">
                                        <v-autocomplete
                                            id="itemsid"
                                            v-model="search_item"
                                            label="검색"
                                            clear-icon="mdi-close-circle"
                                            :append-icon="'mdi-magnify'"
                                            type="text"
                                            :items="searchItemList"
                                            :search-input.sync="searchAdd"
                                            hide-details
                                            item-text="search_name"
                                            item-value="search_name"
                                            return-object
                                            @change="clickAddItemCode, $refs.txt_add__quan.focus()"
                                            ref="autoinput"
                                            @click="searchAdd_void"
                                            @input="onInput"
                                            auto-selct-first                                            
                                            v-on:keyup.enter="$refs.txt_add__quan.focus()"
                                        ></v-autocomplete>
                                    </v-col>
                                    <v-col cols="12">
                                        <v-text-field
                                            ref="lotno"
                                            v-model="lotno"
                                            label="LOT번호"
                                            @keyup="getAddCard_Lotno({lotno:lotno})"
                                            @keyup.enter="$refs.txt_add__quan.focus()"
                                            autofocus
                                            wudth="50%"
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            v-model="add_item_code"
                                            label="품번"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            v-model="add_item_name"
                                            label="품명"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            v-model="add_specification"
                                            label="규격"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            v-model="add_detail_info"
                                            label="상세사양"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12">
                                        <v-text-field
                                            ref="txt_add__quan"
                                            v-model="add_quan"
                                            label="수량"
                                            required
                                            @change="checkQuantity(org_add_quan-add_quan)"
                                        ></v-text-field>
                                    </v-col>

                                    <v-col cols="12">
                                        <v-text-field
                                            v-model="add_bin_code"
                                            label="위치정보"
                                            required
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6" align="center">
                                        <v-btn
                                            tile
                                            color="primary"
                                            @click="execUnitRelease"
                                            :disabled="isDisabled"
                                        >
                                            출고
                                        </v-btn>
                                    </v-col>
                                    <v-col cols="6" align="center">
                                        <v-btn
                                            tile
                                            color="error"
                                            @click="() => dialog_release = false"
                                        >
                                            취소
                                        </v-btn>
                                    </v-col>
                                </v-row>
                            </v-container>
                        </v-card-text>
                    </v-card>
                </div>
                <div id="cards" style="width:30%; height:700px; overflow: scroll;">
                    <!-- <v-card>
                        <v-card-title>위치정보</v-card-title>
                        <v-card-text>A011001</v-card-text>
                    </v-card> -->
                    <v-card 
                        v-for="(card, index) in cards" 
                        :key="index" 
                        style="margin-bottom:1%; background:#c6c6f8;"
                        @click="clickCardBin(card), $refs.txt_add__quan.focus()"  
                    >
                    <v-card-title>{{ card.bin_code }} - {{ card.lotno }}</v-card-title>
                    <v-card-text><td style='width:100%;'>{{ card.item_code + ' : '}}</td><td>{{ card.quan + ' ' + card.unit_code   }}</td></v-card-text>
                    </v-card>
                </div>
            </div>
        </v-dialog>

        <v-dialog
            v-model="dialogCancel"
            width="500px"
            max-width="500px"
        >
            <v-card style="height:180px;">
                <v-card-title>출고취소</v-card-title>
                <v-card-text>선택하신 항목을 출고취소 하시겠습니까?</v-card-text>
                <v-card-actions style="justify-content: end;">
                    <v-btn
                        color="white"
                        style="backgroundColor:green;"
                        text
                        @click="cancelRelease"
                    >확인</v-btn>
                    <v-btn
                        color="white"
                        style="backgroundColor:red;"
                        text
                        @click="dialogCancel = false"
                    >취소</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>

        <v-snackbar
            v-model="snack"
            :timeout="3000"
            :color="snackColor"
            top
        >
            {{ snackText }}
        </v-snackbar>

    </div>
</template>

<script>
import axios from 'axios'

export default {
  name: "Release",
  components: {
    
  }, 
  data() {
    return {
        headers: [
             { value:'lotno', text:'LOT 번호', width:'10%', align:'start', sortable: true,  }, //##DBG lotno 추가
             { value:'item_code', text:'품  번', width:'15%', align:'start', sortable: true, },
             { value:'item_name', text:'품  명', width:'15%', align:'start', sortable: true, },
             { value:'specification', text:'규  격', width:'20%', align:'start', sortable: true, },
             { value:'detail_info', text:'상 세 사 양', width:'10%', align:'start', sortable: true, },
             { value:'his_quan', text:'수  량', width:'10%', align:'start', sortable: true, },
             { value:'bin_code', text:'위 치 정 보', width:'10%', align:'start', sortable: true, },
             { value:'his_date', text:'출 고 날 짜', width:'10%', align:'start', sortable: true, },
             //{ value:'unit_code', text:'단  위', width:'10%', align:' d-none', sortable: true, },
             //{ value:'sum_quan', text:'수  량', width:'10%', align:' d-none', sortable: true},
             //{ value:'safe_quan', text:'안 전 재 고', width:'10%', align:' d-none', sortable: true},
             //{ value:'create_date', text:'Last일자', width:'10%', align:'start', sortable: true},
             //{ value:'change_date', text:'Last 일 자', width:'10%', align:'start', sortable: true},
            
            // { value:'last_in_date', text:'최근출고날짜', width:'25%', align:'start', sortable: true, },
        ],
        headers2: [
            { value:'item_code', text:'품번', width:'15%', align:'center', sortable: true, },
            { value:'item_name', text:'품명', width:'15%', align:'center', sortable: true, },
            { value:'specification', text:'규격', width:'15%', align:'center', sortable: true, },
            { value:'detail_info', text:'상세사양', width:'15%', align:'center', sortable: true, },
            { value:'unit_code', text:'단위', width:'15%', align:'center', sortable: true, },
            { value:'sum_quan', text:'수량', width:'10%', align:'center', sortable: true},
            { value:'safe_quan', text:'안전재고', width:'15%', align:'center', sortable: true},
            
            // { value:'last_in_date', text:'최근출고날짜', width:'25%', align:'start', sortable: true, },
        ],
        i_code:'',  //입고완료시 입고 품번으로 입고 리스트만을 조회하기위한 변수
        chgTable:true,

        datas:[],
        dataCounts:0,
        perPage:100,
        page:1,
        footerProps: { 'items-per-page-options': [100, -1] },
        options:{},
        params:{},

        lot_code:'',

        lotno:null,
        find_mode:0,
        isDisabled:false,
        
        orderBy:null,
        order_desc:false,

        overlay: false,
        dialog_release:false,
        dialogCancel:false,

        searchAdd:null,
        searchItemList:[],

        search_item:null,
        add_item_uid:null,
        add_item_code:null,
        add_item_name:null,
        add_specification:null,
        add_detail_info:null,
        add_quan:null,
        add_bin_code:null,
        add_r_lotno:null,
        org_add_quan:0,

        cards: [],
        selected:[],
        selectedCard:null,
        selectedItem:null, 

        snack:false,
        snackColor:'',
        snackText:'',

        release_date_menu:false,
        date_range:'',
        start_date:'',
        end_date:'',

        inputStart:false,
        inputEnd:false,
        today:'',
        cancelDisabled:true
    };
  },
  mounted() {
    // const element = document.documentElement;
    // if (!document.fullscreenElement) {
    //   element.requestFullscreen();
    // }    

    this.chgTable=false;
    this.init();
    this.set_input_date();
  },
  computed: {
    filteredItems() {
      if (this.items === null || this.items === undefined) {
        return [];
      }
      return this.items.slice();
    },
  },  
  watch: {

    chgTable(newVal) {
        console.log("--------chgTable-------");
        console.log(newVal);

      this.orderBy=null;
      this.order_desc=null;
      if (newVal ===true) {
         this.headers = [
            { value:'lotno', text:'LOT 번 호', width:'10%', align:'start', sortable: true,  }, //##DBG lotno 추가
            { value:'item_code', text:'품번', width:'15%', align:'start', sortable: true, },
            { value:'item_name', text:'품명', width:'15%', align:'start', sortable: true, },
            { value:'specification', text:'규격', width:'20%', align:'start', sortable: true, },
            { value:'detail_info', text:'상세사양', width:'10%', align:'start', sortable: true, },
            { value:'his_quan', text:'수량', width:'10%', align:'start', sortable: true, },
            { value:'bin_code', text:'위치정보', width:'10%', align:'start', sortable: true, },
            { value:'his_date', text:'출고 날짜', width:'10%', align:'start', sortable: true, },
        ];
      } else if (newVal === false) {
        this.headers2 = [
            { value:'item_code', text:'품번', width:'15%', align:'center', sortable: true, },
            { value:'item_name', text:'품명', width:'15%', align:'center', sortable: true, },
            { value:'specification', text:'규격', width:'15%', align:'center', sortable: true, },
            { value:'detail_info', text:'상세사양', width:'15%', align:'center', sortable: true, },
            { value:'unit_code', text:'단위', width:'15%', align:'center', sortable: true, },
            { value:'sum_quan', text:'수량', width:'10%', align:'center', sortable: true},
            { value:'safe_quan', text:'안전재고', width:'15%', align:'center', sortable: true},
        ];
      }
    },

      selected() {
        if(this.selected.length>0) {
            this.cancelDisabled = false
        } else {
            this.cancelDisabled = true
        }
      },

      searchAdd(val) {
        console.log("-----------------searchAdd-------------");
        console.log(val);

          if(val == null || val.length < 1) return;
            var sresult='';
            if(val!='') {
                const str = val;
                const result = str.split("/");
                console.log(result);
                sresult = result[0]; 
            }
            else{
                sresult = '';
            }

            var url = this.$vBACKEND_URL + '/item.do?method=readItem';
            var pObj = {
                uid_company:this.$store.getters.getUidCompany,
                search_item:sresult
                // item_code:val
            }
            var params = '';
            for(var key in pObj) {
                params += '&' + key + '=' + pObj[key]
            }

            url += params;

            fetch(url)
                .then(res => res.clone().json())
                .then(res => {
                    this.searchItemList = res.result
                    console.log(res.result)
                    this.getAddCard(res)                        //##DBG 추가 : item uids가 한템포 늦게 로딩되는 문제로 입고가 안되서 추가(unique_id 잘못됨값)
                    console.log(res.result[0].unique_id)
                    this.item_uids = res.result[0].unique_id  //##DBG 추가 : item uids가 한템포 늦게 로딩되는 문제로 입고가 안되서 추가
                    this.clickAddItemCode(res.result[0])       //##DBG 추가 : 선택한 행의 입고창이 열릴때, 재고 리스트가 나타나지않는문제 수정//this.clickAddItemCode2(res.result[0])       //##DBG 추가 : 선택한 행의 입고창이 열릴때, 재고 리스트가 나타나지않는문제 수정

                })
                .catch(err => {
                    console.log(err)
                })
      },

      release_date_menu() {
          if(this.release_date_menu) {
              this.inputStart = false;
              this.inputEnd = false;
          }
      },
      
     options(val) {
        var curPage = val.page;
        var itemsPerPage = val.itemsPerPage;
        if(itemsPerPage!=null && itemsPerPage==-1) {
            itemsPerPage = 100000000;
        }
        this.page = curPage;
        this.perPage = itemsPerPage;

        //##DBG 추가 정렬
        if(val.sortBy[0]){
            this.orderBy = "&orderBy=" + val.sortBy[0];
            this.order_Desc = "&isAsc=" +  val.sortDesc[0];
        }
        else{
            this.orderBy=null;
            this.order_Desc=null;
        }
        
        if(this.chgTable==true){
            this.getDatas();
        }
        else{
            this.getDatas2();
        }
     }
  },
  
  methods: {
    init() {
        this.getDatas()
    },

    // chgTable2(newVal) {
    //     console.log("--------chgTable2-------");
    //     console.log(newVal);

    //   this.orderBy=null;
    //   this.order_desc=null;
    //   if (newVal ===true) {
    //     //this.headers2=[];
    //     this.headers = [
    //         { value:'lotno', text:'LOT 번 호', width:'10%', align:'start', sortable: true,  }, //##DBG lotno 추가
    //         { value:'item_code', text:'품번', width:'10%', align:'start', sortable: true, },
    //         { value:'item_name', text:'품명', width:'15%', align:'start', sortable: true, },
    //         { value:'specification', text:'규격', width:'10%', align:'start', sortable: true, },
    //         { value:'detail_info', text:'상세사양', width:'10%', align:'start', sortable: true, },
    //         { value:'his_quan', text:'수량', width:'10%', align:'start', sortable: true, },
    //         { value:'bin_code', text:'위치정보', width:'10%', align:'start', sortable: true, },
    //         { value:'his_date', text:'출고 날짜', width:'10%', align:'start', sortable: true, },
    //         { value:'create_date', text:'등록 일자', width:'10%', align:'start', sortable: true},
    //     ];
    //   } else if (newVal === false) {
    //     //this.headers=[];
    //     this.headers2 = [
    //         { value:'item_code', text:'품번', width:'15%', align:'center', sortable: true, },
    //         { value:'item_name', text:'품명', width:'15%', align:'center', sortable: true, },
    //         { value:'specification', text:'규격', width:'15%', align:'center', sortable: true, },
    //         { value:'detail_info', text:'상세사양', width:'15%', align:'center', sortable: true, },
    //         { value:'unit_code', text:'단위', width:'15%', align:'center', sortable: true, },
    //         { value:'sum_quan', text:'수량', width:'10%', align:'center', sortable: true},
    //         { value:'safe_quan', text:'안전재고', width:'15%', align:'center', sortable: true},

    //     ];
    //   }
    // },    
    
    checkQuantity(val) {
        this.isDisabled = val< 0;
    },

    initSort(){
        console.log("---------initSort----------");
        this.chgTable = true;
        this.orderBy=null
        this.order_desc=null;
        this.items = [];
        setTimeout(() => {
            this.getDatas();
            //this.chgTable2(true);
            console.log(this.$refs.dataTable.items[0]);
        }, 10)            
        
    },
    initSort2(){
        console.log("---------initSort----------");
        this.chgTable = false;
        this.orderBy=null
        this.order_desc=null;
        this.items = [];
        setTimeout(() => {
            this.getDatas2();
            //this.chgTable2(false);
            console.log(this.$refs.dataTable.items[0]);
        }, 10)            
    },
    onInput(item){
        console.log("on input:   ", item);
    },
    //##DBG 추가
    disabledSelectAll(){
        console.log("------------diabledSelectAll-------------");
        console.log(this.$refs.dataTable);
        const selectedItems = this.$refs.dataTable.selection;
        console.log(selectedItems);

        for(var key in selectedItems) {
            console.log(key);
            console.log(selectedItems[key]);
            selectedItems[key] = false;
            key = null;
        }
        this.selected = [];
    },
    searchAdd_void() {
        console.log("------------------ searchAdd_void ---------------");

        var url = this.$vBACKEND_URL + '/item.do?method=readItem';
        var pObj = {
            uid_company:this.$store.getters.getUidCompany,
            search_item:''
            // item_code:val
        }
        
        var params = '';
        for(var key in pObj) {
            params += '&' + key + '=' + pObj[key]
        }

        url += params;

        fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                this.searchItemList = res.result
            })
            .catch(err => {
                console.log(err)
            })
    },    
    getDatas() {
        console.log("------------------ getData ---------------");
        console.log(this.headers[0].text);
        // this.headers[4].align="center";
        // this.headers[5].align="center";
        // this.headers[6].align="center";
        // this.headers[7].align=" d-none";
        // this.headers[8].align=" d-none";
        // this.headers[9].align=" d-none";

        var url = this.$vBACKEND_URL + '/stock.do?method=readLocationHistory';
        var start = (this.page-1) * this.perPage;
        var limit = this.perPage;
        var obj = {
          uid_company:this.$store.getters.getUidCompany,
          start:start,
          limit:limit,
          gubun:'OUT',
          apiType:'ALL'
        }

        var params = '';
        for(var key in obj) {
          params += '&' + key + '=' + obj[key]
        }
        if(this.params!=null) {
            for(var k in this.params) {
                params += '&' + k + '=' + this.params[k]
            }
        }
        url += params;

        if(this.orderBy != null && this.orderBy != 'undifined'){
            url += this.orderBy;//"&orderBy=user_name";
            url += this.order_Desc;//"&isAsc=true";
        }
        else{
            url += this.orderBy="&orderBy=his_date";
            url += this.order_Desc="&isAsc=false";            
        }

        console.log(url);

        fetch(url)
          .then(res => res.clone().json())
          .then(res => {
              const datas = res.datas;
              const count = res.count;
              this.datas = datas;
              this.dataCounts = count;
          })
          .catch(err => {console.log(err)})
          .finally(() => {
            this.dialog = false;
          })
    },
    //##DBG 추가 : 재고 리스트
    getDatas2() {
        console.log("------------------ getData2 ---------------");
        console.log(this.headers[0].text);
        // this.headers[4].align=" d-none";
        // this.headers[5].align=" d-none";
        // this.headers[6].align=" d-none";
        // this.headers[7].align="center";
        // this.headers[8].align="center";
        // this.headers[9].align="center";

        var url = this.$vBACKEND_URL + '/item.do?method=readItem';
        var start = (this.page-1) * this.perPage;
        var limit = this.perPage;
        var obj = {
          uid_company:this.$store.getters.getUidCompany,
          start:start,
          limit:limit
        }
        
        var params = '';
        for(var key in obj) {
          params += '&' + key + '=' + obj[key]
        }
        if(this.params!=null) {
            for(var k in this.params) {
                params += '&' + k + '=' + this.params[k]
            }
        }
        url += params;

        if(this.orderBy != null && this.orderBy != 'undifined'){
            console.log(this.orderBy);
            url += this.orderBy;//"&orderBy=user_name";
            url += this.order_Desc;//"&isAsc=true";
        }
        else{
            url += "&orderBy=unique_id";  //change_date
            url += "&isAsc=false";            
        }

        console.log(url);

        fetch(url)
          .then(res => res.clone().json())
          .then(res => {
              const datas = res.result;
              const count = res.count;
              this.datas = datas;
              this.dataCounts = count;
          })
          .catch(err => {console.log(err)})
          .finally(() => {
            
          })

    },
    onClickCol(record, row) {
        const isSelected = row.isSelected;
        if(isSelected) {
            row.select(false);
        } else {
            row.select(true);
        }
    },

    onClickRow(record, row) {
        this.resetAddForm();
        
        console.log("------------onClickRow----------")
        console.log(row.item);
        console.log(row.item.item_code);
        this.dialog_release=true;
        console.log(row.item.lotno);
        if(row.item.lotno==''){
            this.find_mode=0;
        }
        else{
            this.find_mode=1;
        }

        this.org_add_quan = 0;

        if(this.find_mode==0){
        setTimeout(() => {
          this.searchAdd = row.item.item_code;//자동항목 셀렉트박스에 검색용 item 코드 입력
        }, 500)   
        }
        console.log("------------onClickRow 2----------")
        console.log(this.search_item);

        
        if(this.find_mode==0){        
        // 품목코드기준 검색
        this.searchAdd =row.item.item_code;//자동항목 셀렉트박스에 item코드 목록 넣기
        this.selectedItem = row.item;
        }
        else{
        // LOTNO 기준 검색
        this.lotno =row.item.lotno;     // lotno 검색
        }

        if(document.getElementById('itemsid') != null){
            console.log(document.getElementById('itemsid'));
        }
        
        //this.clickAddItemCode(row.item); // itemcode로 item정보 가져옴
        //this.clickAddItemCode2(row.item); // itemcode로 item정보 가져옴

        console.log(this.searchAdd);
        if(this.find_mode==0){
            if(this.$refs.autoinput != null){
                console.log("------------onClickRow 3----------")
                console.log(this.$refs.autoinput);
                
                if(this.$refs.autoinput.items[0] !=null){
                    console.log(".>");
                    console.log(this.$refs.autoinput.items[0].unique_id);            
                    this.add_item_uid = this.$refs.autoinput.items[0].unique_id;
                }
                else{
                    console.log(".>");
                    console.log(this.$refs.autoinput._props.value);
                    console.log(this.$refs.autoinput._props.value.unique_id);            
                    this.add_item_uid = this.$refs.autoinput._props.value.unique_id;
                }
            }

            this.uid_company = this.$store.getters.getUidCompany;
            this.add_item_code = row.item.item_code;
            this.add_item_name = row.item.item_name;
            this.add_specification = row.item.specification;
            this.add_detail_info = row.item.detail_info        
            this.add_quan = row.item.sum_quan   ;
            this.org_add_quan = row.item.sum_quan   ;

            setTimeout(() => {
              this.searchAdd = row.item.item_code;//자동항목 셀렉트박스에 검색용 item 코드 입력
            }, 500)  

        }      
        else{
            setTimeout(() => {
                this.getAddCard_Lotno({lotno:this.lotno});
            }, 500)  
        }
    },

    onClickRow2(record, row) {
        this.resetAddForm();
        
        console.log("------------onClickRow----------")
        console.log(row.item);
        console.log(row.item.item_code);
        this.dialog_release=true;
        
        this.org_add_quan = 0;

        this.find_mode=0;
        if(this.find_mode==0){
        setTimeout(() => {
          this.searchAdd = row.item.item_code;//자동항목 셀렉트박스에 검색용 item 코드 입력
        }, 500)   
        }
        console.log("------------onClickRow 2----------")
        console.log(this.search_item);

        
        if(this.find_mode==0){        
        // 품목코드기준 검색
        this.searchAdd =row.item.item_code;//자동항목 셀렉트박스에 item코드 목록 넣기
        this.selectedItem = row.item;
        }
        else{
        // LOTNO 기준 검색
        this.lotno =row.item.lotno;     // lotno 검색
        }

        if(document.getElementById('itemsid') != null){
            console.log(document.getElementById('itemsid'));
        }
        
        //this.clickAddItemCode(row.item); // itemcode로 item정보 가져옴
        //this.clickAddItemCode2(row.item); // itemcode로 item정보 가져옴

        console.log(this.searchAdd);
        if(this.find_mode==0){
            if(this.$refs.autoinput != null){
                console.log("------------onClickRow 3----------")
                console.log(this.$refs.autoinput);
                
                if(this.$refs.autoinput.items[0] !=null){
                    console.log(".>");
                    console.log(this.$refs.autoinput.items[0].unique_id);            
                    this.add_item_uid = this.$refs.autoinput.items[0].unique_id;
                }
                else{
                    console.log(".>");
                    console.log(this.$refs.autoinput._props.value);
                    console.log(this.$refs.autoinput._props.value.unique_id);            
                    this.add_item_uid = this.$refs.autoinput._props.value.unique_id;
                }
            }

            this.uid_company = this.$store.getters.getUidCompany;
            this.add_item_code = row.item.item_code;
            this.add_item_name = row.item.item_name;
            this.add_specification = row.item.specification;
            this.add_detail_info = row.item.detail_info        
            this.add_quan = row.item.sum_quan   ;
            this.org_add_quan = row.item.sum_quan   ;

            setTimeout(() => {
              this.searchAdd = row.item.item_code;//자동항목 셀렉트박스에 검색용 item 코드 입력
            }, 500)  

        }      
        else{
            setTimeout(() => {
                this.getAddCard_Lotno({lotno:this.lotno});
            }, 500)  
        }
    },

    
    onTextChangne(key, val) {
        console.log('==onTextChangne', key)
        console.log('==onTextChangne val', val)

        if(val==null || val.length<1) {
            this.params[key] = '';
        } else {
            this.params[key] = val;
        }

        // alert(document.getElementById('wearing-item_code').value)
    },

    onTextChangne2(key, val) {
        console.log('==onTextChangne', key)
        console.log('==onTextChangne val', val)

        if(val==null || val.length<1) {
            this.params[key] = '';
        } else {
            this.params[key] = val;
        }

        // alert(document.getElementById('wearing-item_code').value)
    },

    releaseExcelUpload() {
        let input = document.createElement('input')

        input.id = 'excel'
        input.type = 'file'
        input.accept = 'application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        input.multiple = true

        input.click();

        var url = this.$vBACKEND_URL + '/template.do?method=execReleaseExcel'
        var me = this

        // Event
        input.onchange = function() {
            me.overlay = true
            const formData = new FormData()
            formData.append('file', this.files[0])
            formData.append('uid_company', me.$store.getters.getUidCompany)
            formData.append('user_uid', me.$store.getters.getUserUid)
            formData.append('user_id', me.$store.getters.getUserId)
            formData.append('user_name', me.$store.getters.getUserName)

            axios.post(url, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then(res => {
                        console.log(res)
                        me.snack = true;
                        me.snackColor = '#60C5F1';
                        me.snackText = '성공'

                        me.getDatas();
                    }).catch(err => {
                        console.log(err)
                        me.snack = true;
                        me.snackColor = "red";
                        me.snackText = '실패'
                    }).finally(() => {
                        me.overlay = false
                    })
        }
    },

    releaseExcelDownload() {
        this.overlay = true

        var url = this.$vBACKEND_URL + '/stock.do?method=readLocationHistory';
        var obj = {
          uid_company:this.$store.getters.getUidCompany,
        //   start:start,
        //   limit:limit,
          gubun:'OUT',
          apiType:'ALL',
          //orderBy:'history.his_date desc',
          command:'EXCEL'
        }

        var params = '';
        for(var key in obj) {
          params += '&' + key + '=' + obj[key]
        }
        if(this.params!=null) {
            for(var k in this.params) {
                params += '&' + k + '=' + this.params[k]
            }
        }
        url += params;
        //url += this.orderBy;//"&orderBy=user_name";
        //url += this.order_Desc;//"&isAsc=true";

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const excelPath = res.result;
            console.log('==excelPath', excelPath)
            if(excelPath!=null) {
                 this.snack = true;
                 this.snackColor = '#60C5F1';
                 this.snackText = '성공'
                location.href = this.$vCONTENT_URL + "/excel/" + excelPath
            } else {
                 this.snack = true;
                 this.snackColor = 'FFFBE5';
                 this.snackText = '조회된 데이터가 없습니다.'
            }
            this.overlay = false
        })
        .catch(err => {
            console.log(err)
            this.snack = true;
            this.snackColor = 'red';
            this.snackText = '실패'
            this.overlay = false
        })
        .finally(() => this.overlay = false)
    },

    releaseExcelTemplate() {
        this.overlay = true
        var url = this.$vBACKEND_URL + '/template.do?method=releaseExcelTemplateDown';
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
        }
        var params = '';
        for(var key in obj) {
        params += '&' + key + '=' + obj[key]
        }
        url += params;

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const excelPath = res.result;
            console.log('==excelPath', excelPath)
            if(excelPath!=null) {
                // this.snack = true;
                // this.snackColor = '#60C5F1';
                // this.snackText = '성공'
                location.href = this.$vCONTENT_URL + "/excel/" + excelPath
            } else {
                // this.snack = true;
                // this.snackColor = 'FFFBE5';
                // this.snackText = '조회된 데이터가 없습니다.'
            }
            this.overlay = false
        })
        .catch(err => {
            console.log(err)
            this.snack = true;
            this.snackColor = 'red';
            this.snackText = '실패'
            this.overlay = false
        })
        .finally(() => this.overlay = false)
    }, 

    clickCardBin(card) {
        this.selectedCard = card;
        this.add_quan = card.quan;
        this.add_bin_code = card.bin_code;
        this.lotno = card.lotno;
        this.org_add_quan = card.quan;
        //##DBG add
        console.log("-------clickCardBin(card)----------");
        console.log(card);
        console.log(card.item_code);

        this.add_item_code = card.item_code;
        this.add_item_name = card.item_name;
        this.add_specification = card.specification;
        this.add_detail_info = card.detail_info;
        //this.add_r_lotno =  card.lotno;
    },

    clickAddItemCode(o) {
        console.log(o);
        if(o!=null) {
            this.selectedItem = o;
            this.lotno = o.lotno;
            this.add_item_uid = o.unique_id
            this.add_item_code = o.item_code
            this.add_item_name = o.item_name
            this.add_specification = o.specification
            this.add_detail_info = o.detail_info
            
            this.getAddCard(o);
        }
    },

    // clickAddItemCode2(o) {
    //     if(o!=null) {
    //         this.selectedItem = o;
    //         this.add_item_uid = o.unique_id
    //         this.add_item_code = o.item_code
    //         this.add_item_name = o.item_name
    //         this.add_specification = o.specification
    //         this.add_detail_info = o.detail_info

    //         this.getAddCard(o);
    //     }
    // },

    getAddCard(o) {
        // if(this.add_item_code == null || this.add_item_code.length<1) return;

        if(o==null || o.length<1) return;

        var url = this.$vBACKEND_URL + '/stock.do?method=readLocationByUidItem';
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
            uid_item:this.add_item_uid
        }
        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' + obj[key]
        }
        url += params;

        console.log(url); // http://14.45.14.42:1003/stock.do?method=readLocationByUidItem&uid_company=101000002025&uid_item=106000033798

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const cards = res.result;
            this.cards = cards;
            console.log("------------getAddCard(o)------------");
            console.log(this.cards);
        })
        .catch(err => {
            console.log(err)
        })
    },

    getAddCard_Lotno(o) {
        // if(this.add_item_code == null || this.add_item_code.length<1) return;

        if(o==null || o.length<1) return;

        var url = this.$vBACKEND_URL + '/stock.do?method=readLocationByUidItem';
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
            lotno:o.lotno
        }
        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' + obj[key]
        }
        url += params;

        console.log(url); // http://14.45.14.42:1003/stock.do?method=readLocationByUidItem&uid_company=101000002025&uid_item=106000033798

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const cards = res.result;
            this.cards = cards;
            console.log(this.cards);
            this.add_item_uid = cards[0].unique_id
            this.add_item_code = cards[0].item_code
            this.add_item_name = cards[0].item_name
            this.add_specification = cards[0].specification
            this.add_detail_info = cards[0].detail_info
            //this.add_r_lotno =  cards[0].lotno;
        })
        .catch(err => {
            console.log(err)
        })
    },

    execUnitRelease() {
        this.chgTable = true; // 출고와 동시에 출고 내역 리스트로 화면 변경하여 방금 출고한 항목 조회함
        if(this.add_item_code==null) {
            this.snack = true;
            this.snackColor = "red";
            this.snackText = '품번을 확인해주세요'
            return;
        }
        if(this.add_bin_code==null) {
            this.snack = true;
            this.snackColor = "red";
            this.snackText = '위치정보를 확인해주세요'
            return;
        }
        if(this.add_quan==null) {
            this.snack = true;
            this.snackColor = "red";
            this.snackText = '수량을 확인해주세요'
            return;
        }

        var url = this.$vBACKEND_URL + '/stock.do?method=execRelease';
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
            user_uid:this.$store.getters.getUserUid,
            user_id:this.$store.getters.getUserId,
            user_name:this.$store.getters.getUserName,
            location_uids:this.selectedCard.unique_id,
            location_quans:this.add_quan,
            set_lotno:this.selectedCard.lotno,
        }
        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' + obj[key]
        }
        url += params;

        console.log(url);
        fetch(url)
        .then(res => {
            this.snack = true;
            this.snackColor = '#60C5F1';
            this.snackText = '출고 성공'
        })
        .catch(err => {
            this.snack = true;
            this.snackColor = 'red';
            this.snackText = '실패'
            console.log(err)
        })
        .finally(() => this.resetAddForm())

        //##DBG 추가 : 입고된 상품코드로 입고리스트 조회되도록 동작
        this.item_code =this.add_item_code;
        console.log(this.add_item_code);
        this.i_code = this.add_item_code;
        this.$emit('i_code_update');
        this.onTextChangne('item_code', this.add_item_code)
        if(this.chgTable==true){
            this.getDatas();
        }
        else{
            this.getDatas2();
        }
        this.$refs.lotno.focus()

    },

    resetAddForm() {
        this.add_item_uid = null
        this.search_item = null
        this.add_item_code = null
        this.add_item_name = null
        this.add_specification = null
        this.add_detail_info = null
        this.add_quan = null
        this.add_bin_code = null
        this.cards = null
        this.selectedCard = null
        this.selectedItem = null
        this.lotno = null;
        this.searchItemList = [];
        this.search_item = null;   
        this.add_r_lotno = null;     
        this.cancelDisabled == false
        this.selected = [];
        this.i_code=null;
        this.lot_code=null;
    },

    set_input_date(){
        const currentDate = new Date();
        const year = currentDate.getFullYear();
        const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        const day = currentDate.getDate().toString().padStart(2, '0');
        this.today = `${year}-${month}-${day}`;    

        this.$refs.start_date = this.today;
        this.$refs.end_date = this.today;

        // const initialDate = new Date();
        // initialDate.setFullYear(2023); // 년도 설정
        // initialDate.setMonth(4); // 월 설정 (0부터 시작하므로 4는 5월을 의미)
        // initialDate.setDate(12); // 일 설정
        // this.start_date = initialDate;
        // this.end_date = initialDate;

        const initialDate = new Date('2023-05-12');

        this.start_date = this.today;
        this.end_date = this.today;
        this.input_start();
        this.input_end();
    },


    input_start() {
        if(this.inputEnd) {
            this.date_range = this.start_date + " ~ " + this.end_date;
            this.release_date_menu = false;
            this.setDateRangeParam();
        }
        this.inputStart = true;
    },

    input_end() {
        if(this.inputStart) {
            this.date_range = this.start_date + " ~ " + this.end_date;
            this.release_date_menu = false;
            this.setDateRangeParam();
        }
        this.inputEnd = true;
    },

    setDateRangeParam() {
        if(this.start_date!=null && this.start_date.length>0 &&
            this.end_date!=null && this.end_date.length>0) {
            this.params['his_s_date'] = this.start_date;
            this.params['his_e_date'] = this.end_date;
        }
    },

    refreshDateRange() {
        this.start_date = '';
        this.end_date = '';
        this.date_range = '';
        this.params['his_s_date'] = '';
        this.params['his_e_date'] = '';
    },

    cancelRelease() {
        this.overlay = true

        var uids = [];
        for(var i=0; i<this.selected.length; i++) {
            const select = this.selected[i]
            const uid = select.id;
            uids.push(uid)
        }

        var url = this.$vBACKEND_URL + '/stock.do?method=cancelInOut'
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
            user_uid:this.$store.getters.getUserUid,
            user_id:this.$store.getters.getUserId,
            user_name:this.$store.getters.getUserName,
        }
        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' + obj[key]
        }
        params += '&' + 'unique_id_list=' + uids
        url += params

        fetch(url)
        // .then(res => res.clone().json())
        .then(res => {
            this.snack = true;
            this.snackColor = 'green';
            this.snackText = '성공'

            this.getDatas()
        })
        .catch(err => {
            console.log(err)
            this.snack = true;
            this.snackColor = 'red';
            this.snackText = '실패'
        })
        .finally(() => {
            this.dialogCancel = false
            this.overlay = false
            this.cancelDisabled = true
        })

    }
  }
};
</script>

<style>
.v-data-table__wrapper {
    height:72vh !important;
}
.v-card {
    white-space: nowrap;
  }
</style>