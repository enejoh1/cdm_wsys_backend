<!-- <template>
  <div>
  <v-text-field v-model="search" label="이름 검색"></v-text-field>
  
  <v-data-table 
    headers="headers" :items="filteredItems"
    v-model="selectedName" :options="nameOptions"
  ></v-data-table>
</div>
</template>

<script>
export default {
  data() {
    return {
      search: '', // 검색어를 저장할 변수
      headers: [
        // 테이블 헤더에 이름, 주소, 전화 열 추가
        { text: '이름', value: 'name' },
        { text: '주소', value: 'address' },
        { text: '전화', value: 'phone' },
      ],
      items: [
        // 임의의 데이터 10개 추가
        { name: '홍길동', address: '서울시 강남구', phone: '010-1234-5678' },
        { name: '김철수', address: '경기도 수원시', phone: '010-2345-6789' },
        { name: '이영희', address: '인천광역시 부평구', phone: '010-3456-7890' },
        { name: '박민수', address: '대전광역시 유성구', phone: '010-4567-8901' },
        { name: '최영진', address: '부산광역시 해운대구', phone: '010-5678-9012' },
        { name: '장현우', address: '울산광역시 남구', phone: '010-6789-0123' },
        { name: '송지은', address: '광주광역시 동구', phone: '010-7890-1234' },
        { name: '이승민', address: '대구광역시 중구', phone: '010-8901-2345' },
        { name: '김민지', address: '경상북도 구미시', phone: '010-9012-3456' },
        { name: '박지현', address: '경상남도 창원시', phone: '010-0123-4567' },
      ],
      selectedName: '', // 선택된 이름을 저장할 변수
      nameOptions: ['홍길동', '김철수', '이영희', '박민수'] // 검색 가능한 이름 목록
    };
  },
  components: {
    //autocomplete: require('vuejs-auto-complete') // autocomplete 컴포넌트 불러오기
  },
  computed: {
    filteredItems() { // 검색어에 따라 필터링된 아이템을 반환하는 computed 속성
      return this.items.filter(item => item.name.includes(this.search));
    },
  },  
};
</script> -->

<!-- 이름을 검색하여 <v-data-table> 상의 데이터를 실시간 검색하는 코드 -->

<!-- <template>
  <div>
    <v-text-field v-model="search" label="이름 검색"></v-text-field>
    <v-data-table :headers="headers" :items="filteredItems"></v-data-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      search: '', // 검색어를 저장할 변수
      headers: [ // 테이블 헤더
        { text: '이름', value: 'name' },
        { text: '나이', value: 'age' },
        { text: '성별', value: 'gender' },
      ],
      items: [ // 테이블 아이템
        { name: '홍길동', age: 20, gender: '남' },
        { name: '김영희', age: 25, gender: '여' },
        { name: '이철수', age: 30, gender: '남' },
      ],
    };
  },
  computed: {
    filteredItems() { // 검색어에 따라 필터링된 아이템을 반환하는 computed 속성
      return this.items.filter(item => item.name.includes(this.search));
    },
  },
};
</script> -->

<!-- 이름을 검색하여 <autocomplete> 상의 데이터를 실시간 검색하는 코드 -->
  <!-- <template>
    <div>
      <input type="text" v-model="searchTerm" @input="search" placeholder="이름을 입력하세요">
      <ul>
        <li v-for="result in results" :key="result.id">{{ result.name }}</li>
      </ul>
    </div>
</template>

<script>
export default {
  data() {
    return {
      searchTerm: '',
      results: []
    }
  },
  methods: {
    search() {
      // 검색어가 비어있으면 결과를 초기화
      if (this.searchTerm === '') {
        this.results = []
        return
      }
      // 검색어가 포함된 데이터를 찾아 결과에 추가
      this.results = this.data.filter(result => {
        return result.name.toLowerCase().includes(this.searchTerm.toLowerCase())
      })
    }
  },
  computed: {
    data() {
      // 검색 대상 데이터
      return [
        { id: 1, name: '김철수' },
        { id: 2, name: '박영희' },
        { id: 3, name: '김민호' },
        { id: 4, name: '최지우' },
        { id: 5, name: '홍호동' }
      ]
    }
  }
}
</script> -->

<!-- 이름을 검색하여 <autocomplete> 상의 데이터를 실시간 검색해서 보여주고, 입력된 이름이 없거나 마우스 클릭시에는 모든 이름을 보여주는 코드 -->

<!-- <template>
  <div>

    <input type="text" v-model="searchTerm" @input="search" placeholder="이름을 입력하세요" @click="search">

    <ul>

      <li v-for="result in results" :key="result.id">{{ result.name }}</li>
    </ul>
  </div>
</template> -->

<!-- 
<script>
export default {
  data() {
    return {
      // 검색어
      searchTerm: '',
      // 검색 결과
      results: []
    }
  },
  methods: {
    search() {
      // 검색어가 비어있으면 모든 데이터를 결과에 추가
      if (this.searchTerm === '') {
        this.results = this.data
        return
      }
      // 검색어가 포함된 데이터를 찾아 결과에 추가
      this.results = this.data.filter(result => {
        return result.name.toLowerCase().includes(this.searchTerm.toLowerCase())
      })
    }
  },
  computed: {
    data() {
      // 검색 대상 데이터
      return [
        { id: 1, name: '김철수' },
        { id: 2, name: '박영희' },
        { id: 3, name: '김민호' },
        { id: 4, name: '최지우' },
        { id: 5, name: '홍호동' }
      ]
    }
  }
}
</script> -->

<!-- 이름을 검색하여  데이터를 실시간 검색해서 보여주고, 입력된 이름이 없거나 마우스 클릭시에는 모든 이름을 보여주는 코드 -->
<!-- <template>
  <div>
    <input type="text" v-model="search" @input="filterNames" placeholder="이름을 입력하세요">
    <ul v-if="showNames">
      <li v-for="(name, index) in filteredNames" :key="index" @click="selectName(name)">
        {{ name }}
      </li>
    </ul>
    <ul v-else>
      <li v-for="(name, index) in allNames" :key="index" @click="selectName(name)">
        {{ name }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      allNames: ['김철수', '박영희', '이민호', '최지우', '홍길동'], // 모든 이름을 담은 배열
      filteredNames: [], // 검색된 이름을 담을 배열
      search: '', // 검색어를 담을 변수
      showNames: false // 검색 결과를 보여줄지 모든 이름을 보여줄지 결정하는 변수
    }
  },
  methods: {
    filterNames() {
      if (this.search) { // 검색어가 있을 경우
        this.filteredNames = this.allNames.filter(name => name.includes(this.search)) // 검색어가 포함된 이름만 필터링
        this.showNames = true // 검색 결과를 보여줌
      } else { // 검색어가 없을 경우
        this.showNames = false // 모든 이름을 보여줌
      }
    },
    selectName(name) {
      this.search = name // 선택한 이름으로 검색어를 변경
      this.showNames = false // 검색 결과를 보여주지 않음
    }
  }
}
</script> -->

<!-- 이름을 검색하여  <v-autocomplete>상의 데이터를 실시간 검색해서 보여주고, 입력된 이름이 없거나 마우스 클릭시에는 모든 이름을 보여주는 코드 -->
<!-- <template>
  <v-autocomplete v-model="selectedName" :items="filteredNames" :search-input.sync="search" label="이름" clearable
    @click:clear="clearSearch" />
</template>

<script>
export default {
  data() {
    return {
      names: ['김철수', '박영희', '이민호', '최지우', '홍길동'],
      search: '',
      selectedName: '',
    };
  },
  computed: {
    // 검색어에 따라 필터링된 이름 목록을 반환하는 computed 속성
    filteredNames() {
      if (!this.search) {
        // 검색어가 없으면 모든 이름을 반환
        return this.names;
      } else {
        // 검색어가 있으면 검색어를 포함하는 이름만 반환
        return this.names.filter((name) =>
          name.toLowerCase().includes(this.search.toLowerCase())
        );
      }
    },
  },
  methods: {
    // 검색어를 초기화하는 메소드
    clearSearch() {
      this.search = '';
    },
  },
};
</script> -->

<!-- 이름을 검색하여  <v-autocomplete>상의 데이터를 실시간 검색해서 보여주고, 입력된 이름이 없거나 마우스 클릭시에는 모든 이름,전화번호을 보여주는 코드 -->
<!-- 아래 코드에서 입력 버턴을 눌러 <v-dialog>를 뛰우는 코드를 추가하라.   -->
<!-- 아래 코드의 <v-dialog> 안에 <v-autocomplate> 추가하는 코드 작성-->  
  <!--아래 코드의  <v-autocomplate> 안에 이름 리스트를 넣어줘 -->
    <!-- 아래 코드에서 <v-data-table>의 행을 클릭하면 선택한 행의 이름으로 <v-dialog>안의 <v-autocomplete> 안의 이름을 조회 하는 코드를 추가해줘 -->
<!--아래의 코드에서 행에서 선택한 이름으로  코드안의 <v-dialog>를 open하고 <v-dialog>안의 <v-autocomplete>의 이름을 조회하는 코드를 추가해줘-->
  <!-- 아래 코드에서 <v-data-table>의 행을 선택하면 <-vialog>를 보이게하는 코드를 추가해줘-->
<!-- 아래 코드에서 <v-data-table>의 행을 클리하면  행의 이름으로 <v-complete>의 이름을 건색하는 코드를 추가해줘  -->  

  <!--아래 코드에서 "리셋" 버턴을 누르면 <v-data-table>의 선택된 checkbox를 모두 unchecker 되도록 코드 수정-->
    <template>
      <div>
        <div>&nbsp;</div>
        <v-hover v-slot="{ hover }">
        <v-btn color="primary"  @click="resetSelected" :elevation="hover ? '10' : '3'">리셋</v-btn>
        </v-hover>
        <v-hover v-slot="{ hover }">
        <!-- 입력 버튼 -->
        <v-btn color="primary" @click="dialog = true" :elevation="hover ? '10' : '3'">입력</v-btn>
        </v-hover>
        <!-- 검색어를 입력하는 input field -->
        <v-text-field v-model="search" label="이름 검색"></v-text-field>
        <!-- 검색 결과를 보여주는 data table -->
        <v-data-table 
            v-model="sel"
            ref="table1" 
            :headers="headers" 
            :items="filteredItems" 
            @click:row="selectRow" 
            @click:col[0]="onClickCol"
            item-selected
            show-select
            dense
          >
          </v-data-table>

        <!-- 입력 버튼을 누르면 뜨는 dialog -->
        <v-dialog v-model="dialog" max-width="500px">
          <v-card>
            <v-card-title>
              <span class="headline">Dialog</span>
            </v-card-title>
            <v-card-text>
              The dialog content goes here.
            </v-card-text>
            <!-- v-autocomplete 추가 -->
            <v-autocomplete 
                v-model="selectedItem" 
                :search-input.sync="searchAdd" 
                :items="nameList" 
                label="이름" 
                item-text="name" 
                item-value="name"
                return-object
    
                activator="parent"
              @change="searchName"></v-autocomplete>
            <v-card-actions>
              <v-btn color="blue darken-1" text @click="dialog = false">Close</v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
      </div>
    </template>
    
    <script>
    export default {
      data() {
        return {
          search: '', // 검색어를 저장하는 변수
          headers: [
            { text: '이름', value: 'name' },
            { text: '전화번호', value: 'phone' }
          ],
          items: [ // 전체 데이터
            { name: '김철수', phone: '010-1234-5678' },
            { name: '박영희', phone: '010-2345-6789' },
            { name: '이민호', phone: '010-3456-7890' },
            { name: '최지우', phone: '010-3456-7890' },
            { name: '한예슬', phone: '010-3456-7890' }
          ],
          nameList: [
            { id: 1, name: '김철수' },
            { id: 2, name: '박영희' },
            { id: 3, name: '이민호' },
            { id: 4, name: '최지우' },
            { id: 5, name: '한예슬' },
          ],
          sel:'',
          selected: {},
          dialog: false, // dialog를 띄우는 변수
          selectedItem: null, // 선택된 아이템을 저장하는 변수
          searchAdd:null,
        }
      },
      computed: {
        filteredItems() { // 검색어에 따라 필터링된 데이터를 반환하는 computed 속성
          if (!this.search) { // 검색어가 없으면 전체 데이터 반환
            return this.items
          }
          return this.items.filter(item => item.name.includes(this.search)) // 검색어가 포함된 데이터만 반환
        }
      },
      mounted(){
        //this.selectRow_void();
        //this.selectRow_void2();
      },
      methods: {
        onClickCol(record, row) {
            const isSelected = row.isSelected;
            if(isSelected) {
                row.select(false);
            } else {
                row.select(true);
            }
        },        
        selectRow(item) { // 행을 클릭하면 선택된 행의 이름을 출력하는 메소드
          this.dialog = true;
          console.log(`선택된 이름: ${item.name}`);
    
          this.searchAdd = "";
    
            //this.selectedItem = item.name; // 선택된 행의 이름을 v-autocomplete에 표시
            setTimeout(() => {
              this.searchAdd = item.name;
            }, 500)
    
          
        },
        selectRow_void() { // 행을 클릭하면 선택된 행의 이름을 출력하는 메소드
          //this.dialog = true;
          this.searchAdd = "";
    
        },
        selectRow_void2() { // 행을 클릭하면 선택된 행의 이름을 출력하는 메소드
          this.dialog = false;
        },
        searchName() { // 선택된 이름을 검색하는 메소드
          console.log(`선택된 이름: ${this.selectedItem}`);
        },
        resetSelected(){
            console.log(this.$refs.table1.select);
            //this.items = [];
            
        }
      },
    }
    </script>

  
 
<!-- <template>
  <v-autocomplete v-model="selectedName" :items="nameList" label="이름" item-text="name" item-value="id"
    @change="searchName"></v-autocomplete>
</template>

<script>
export default {
  data() {
    return {
      selectedName: null,
      nameList: [
        { id: 1, name: '김철수' },
        { id: 2, name: '박영희' },
        { id: 3, name: '이민호' },
        { id: 4, name: '최지우' },
        { id: 5, name: '한예슬' },
      ],
    };
  },
  methods: {
    searchName() {
      // 선택된 이름을 검색하는 로직을 작성해준다.
      console.log(`선택된 이름: ${this.selectedName}`);
    },
  },
};
</script> -->




<!-- <template>
    <v-layout>
      <v-flex xs4>
        <v-card >
          <v-card-title>
            <span class="headline">Menu</span>
          </v-card-title>
          <v-card-text>
            <v-layout column >
              <v-btn v-for="(menu, index) in menus" :key="index" @click="changePage(index)">
                <v-icon>{{ icons[index] }}</v-icon>
                {{ menu }}
              </v-btn>
            </v-layout>
          </v-card-text>
        </v-card>
      </v-flex>
      <v-flex xs8>
        <v-card>
          <v-card-title>
            <span class="headline">{{ currentPage }}</span>
          </v-card-title>
          <v-card-text>
            <component :is="currentPage"></component>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
  </template>
  
  <script>
  import Page1 from './Login.vue'
  import Page2 from './Release.vue'
  import Page3 from './StockMove.vue'
  import Page4 from './UserMgmt.vue'
  import Page5 from './Wearing.vue'
  
  export default {
    name: 'App',
    components: {
      Page1,
      Page2,
      Page3,
      Page4,
      Page5
    },
    data() {
      return {
        menus: ['menu1', 'menu2', 'menu3', 'menu4', 'menu5'],
        icons: ['mdi-home', 'mdi-account', 'mdi-settings', 'mdi-email', 'mdi-help-circle'],
        currentPage: 'Page1'
      }
    },
    methods: {
      changePage(index) {
        switch (index) {
          case 0:
            this.currentPage = 'Page1'
            break
          case 1:
            this.currentPage = 'Page2'
            break
          case 2:
            this.currentPage = 'Page3'
            break
          case 3:
            this.currentPage = 'Page4'
            break
          case 4:
            this.currentPage = 'Page5'
            break
        }
      }
    }
  }
  </script> -->

