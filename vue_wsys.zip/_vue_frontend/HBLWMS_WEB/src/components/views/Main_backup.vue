
<template>
    <v-container style="width:70%; height:100%; padding-top:5%;">
        <v-container style="width:80%; height:40%;">
            <v-card style="display:flex; background:#f2f2f1; border:none;">
                <v-card-actions>
                    <v-icon
                        large
                        colo="green"
                        style="font-size:8vh; color:#2A5786; "
                    >
                        mdi-account-circle
                    </v-icon>
                </v-card-actions>
                <div>
                    <v-card-text style="font-size:24px; font-weight:bold; color:#405E97; padding: 0; padding-top:20%;">
                        {{this.user_name}} 님
                    </v-card-text>
                    <v-card-text style="font-weight:bold; color:#5A8EF6; padding: 0; padding-top:5%;">
                        환영합니다!
                    </v-card-text>
                </div>
                <v-spacer></v-spacer>
                <v-btn
                    color='#CE7D8A'
                    style="position:absolute; top:5%; right:0; color:white;"
                    :hidden="checkUserGrade"
                    width="120px"
                    @click="logout"
                >
                    사용자관리
                </v-btn>
                <v-btn
                    color='blue'
                    style="position:absolute; top:55%; right:0; color:white;"
                    width="120px"
                    @click="logout"
                >
                    로그아웃
                </v-btn>
                <!-- <div 
                    style="border:1px solid; border-radius:5%; height:auto; position:absolute; right:0; top:60%; 
                        margin-right:2%; background:white; color:gray;"
                    @click="logout"
                >
                    로그아웃
                </div> -->
            </v-card>
            <!-- <div style="width:100%; height:40%; background:white; margin-top:5%;
                        padding-top:5%; padding-left:5%; color:#2A5786;"> -->
            <div style="width:100%; height:40%; background:white; color:#2A5786;">
                재고관리 시스템을 이용하기 위해<br>품목정보와 위치정보를 설정하는 화면입니다.
            </div>
        </v-container>
        
        <v-container style="width:90%; height:40%; display:flex;">
            <v-card style="width:50%; height:100%; text-align:center;">
                <v-card-title style="justify-content: center;">품목</v-card-title>
                <v-card-text style="display:flex; margin-top:3%;">
                    <v-sheet
                        class="d-flex"
                        color="grey lighten-3"
                        width="30%"
                        height="120px"
                        style="justify-content: center; align-items: center;"
                        @click="uploadExcelItem"
                    >
                        <div>
                            <div style="width:100%; height:80%;">
                                <img src="../../assets/icons/excel.png" style="width:50%; height:50%;" />
                            </div>
                            <div style="width:100%; height:20%; text-align:right;">
                                <v-icon
                                    large
                                    colo="green"
                                    style="color:#2A5786; "
                                >
                                    mdi-tray-arrow-up
                                </v-icon>
                            </div>
                        </div>
                    </v-sheet>
                    <v-sheet
                        class="d-flex"
                        color="grey lighten-3"
                        width="30%"
                        height="120px"
                        style="margin-left:5%; justify-content: center; align-items: center;"
                        @click="templateExcelItem"
                    >
                        <div>
                            <div style="width:100%; height:80%;">
                                <img src="../../assets/icons/excel.png" style="width:50%; height:50%;" />
                            </div>
                            <div style="width:100%; height:20%; text-align:right;">
                                <v-icon
                                    large
                                    colo="green"
                                    style="color:#2A5786; "
                                >
                                    mdi-tray-arrow-down
                                </v-icon>
                            </div>
                        </div>
                    </v-sheet>
                    <v-sheet
                        class="d-flex"
                        color="grey lighten-3"
                        width="30%"
                        height="120px"
                        style="margin-left:5%; justify-content: center; align-items: center;"
                        @click="downloadExcelItem"
                    >
                        <div>
                            <div style="width:100%; height:80%;">
                                <img src="../../assets/icons/excel.png" style="width:50%; height:50%;" />
                            </div>
                            <div style="width:100%; height:20%; text-align:right;">
                                <v-icon
                                    large
                                    colo="green"
                                    style="color:#2A5786; "
                                >
                                    mdi-barcode
                                </v-icon>
                            </div>
                        </div>
                    </v-sheet>
                </v-card-text>
                <div style="width:100%; display:flex;">
                    <div style="width:33%;">
                        <v-card-text style="text-align:center; color:#5A8EF6;">템플릿 업로드_</v-card-text>
                    </div>
                    <div style="width:33%;">
                        <v-card-text style="text-align:center; color:#5A8EF6;">템플릿 다운로드</v-card-text>
                    </div>
                    <div style="width:33%;">
                        <v-card-text style="text-align:center; color:#5A8EF6;">바코드 템플릿<br>다운로드</v-card-text>
                    </div>
                </div>
            </v-card>
            <v-card style="width:50%; height:100%; margin-left:10%; text-align:center;">
                <v-card-title style="justify-content: center;">위치정보</v-card-title>
                <v-card-text style="display:flex; margin-top:3%;">
                    <v-sheet
                        class="d-flex"
                        color="grey lighten-3"
                        width="30%"
                        height="120px"
                        style="justify-content: center; align-items: center;"
                        @click="uploadExcelLocation"
                    >
                        <div>
                            <div style="width:100%; height:80%;">
                                <img src="../../assets/icons/excel.png" style="width:50%; height:50%;" />
                            </div>
                            <div style="width:100%; height:20%; text-align:right;">
                                <v-icon
                                    large
                                    colo="green"
                                    style="color:#2A5786; "
                                >
                                    mdi-tray-arrow-up
                                </v-icon>
                            </div>
                        </div>
                    </v-sheet>
                    <v-sheet
                        class="d-flex"
                        color="grey lighten-3"
                        width="30%"
                        height="120px"
                        style="margin-left:10%; justify-content: center; align-items: center;"
                        @click="downloadExcelLocation"
                    >
                        <div>
                            <div style="width:100%; height:80%;">
                                <img src="../../assets/icons/excel.png" style="width:50%; height:50%;" />
                            </div>
                            <div style="width:100%; height:20%; text-align:right;">
                                <v-icon
                                    large
                                    colo="green"
                                    style="color:#2A5786; "
                                >
                                    mdi-tray-arrow-down
                                </v-icon>
                            </div>
                        </div>
                    </v-sheet>
                    <v-sheet
                        class="d-flex"
                        color="grey lighten-3"
                        width="30%"
                        height="120px"
                        style="margin-left:10%; justify-content: center; align-items: center;"
                        @click="excelLocationBarcode"
                    >
                        <div>
                            <div style="width:100%; height:80%;">
                                <img src="../../assets/icons/excel.png" style="width:50%; height:50%;" />
                            </div>
                            <div style="width:100%; height:20%; text-align:right;">
                                <v-icon
                                    large
                                    colo="green"
                                    style="color:#2A5786; "
                                >
                                    mdi-barcode
                                </v-icon>
                            </div>
                        </div>
                    </v-sheet>
                </v-card-text>
                <div style="width:100%; display:flex;">
                    <div style="width:33%;">
                        <v-card-text style="text-align:center; color:#5A8EF6;">템플릿 업로드</v-card-text>
                    </div>
                    <div style="width:33%;">
                        <v-card-text style="text-align:center; color:#5A8EF6;">템플릿 다운로드</v-card-text>
                    </div>
                    <div style="width:33%;">
                        <v-card-text style="text-align:center; color:#5A8EF6;">바코드 템플릿<br>다운로드</v-card-text>
                    </div>
                </div>
            </v-card>
        </v-container>

        <v-dialog
            v-model="dialogLogout"
            max-width="400"
        >
        <v-card>
            <v-card-title class="text-h5" style="font-weight: bold;">
            로그아웃
            </v-card-title>
            <v-card-text class="text-h7" style="font-weight: bold;">
            로그인 페이지로 돌아가시겠습니까?
            </v-card-text>
            <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
                style="width:40%; background-color: rgb(103, 173, 219); color:white;"
                @click="logout_confirm"
            >
                로그아웃
            </v-btn>
            <v-btn
                style="width:40%; background-color: rgb(103, 173, 219); color:white;"
                @click="dialogLogout = false"
            >
                취소
            </v-btn>
            </v-card-actions>
        </v-card>
        </v-dialog>

        <v-snackbar
            v-model="snackbar"
            :top="true"
            :color="snackResult"
            :timeout="3000"
        >
            <div style="text-align:center;">{{snackText}}</div>
            <template v-slot:action="{ attrs }">
                <v-btn
                color="blue"
                text
                v-bind="attrs"
                @click="snackbar = false"
                >
                Close
                </v-btn>
            </template>
        </v-snackbar>

    </v-container>
</template>

<script>
import axios from 'axios'

export default {
    name:'Main_backup',
    data() {
        return {
            uid_company:null,
            user_uid:null,
            user_id:null,
            user_name:null,
            
            dialogLogout:false,
            snackbar:false,
            snackResult:null,
            snackText:null
        }
    },
    mounted() {
        this.init();
    },
    components: {

    },
    watch: {

    },
    methods: {
        init() {
            // 사용자 정보 호출
            const userInfo = this.$store.getters.getLoginDatas;
            console.log('=== userInfo', userInfo)
            this.uid_company = userInfo.uid_company
            this.user_uid = userInfo.user_uid
            this.user_id = userInfo.user_id
            this.user_name = userInfo.user_name
        },
        goToMenu(path) {
            this.$router.push(path);
        },
        logout() {
            this.dialogLogout = true
        },
        logout_confirm() {
            this.dialogLogout = false
            this.$store.commit('clearUserInfo')
            this.$router.replace('login')
        },
        checkUserGrade() {
            const user_id = this.$store.getters.getUserId
            if(user_id!=null && (user_id == 'admin' || user_id == 'root')) {
                return false
            } else {
                return true
            }
        },
        uploadExcelItem() {
            let input = document.createElement('input')

            input.id = 'excel'
            input.type = 'file'
            input.accept = 'application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            input.multiple = true

            input.click();

            var url = this.$vBACKEND_URL + '/item.do?method=itemExcelUpload'
            var me = this

            // Event
            input.onchange = function() {
            const formData = new FormData()
            formData.append('file', this.files[0])
            formData.append('uid_company', me.$store.getters.getUidCompany)
            formData.append('user_uid', me.$store.getters.getUserUid)
            formData.append('user_id', me.$store.getters.getUserId)
            formData.append('user_name', me.$store.getters.getUserName)

            axios.post(url, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then(res => {
                        console.log(res)
                        me.snackbar = true;
                        me.snackResult = '#60C5F1';
                        me.snackText = '성공'
                    }).catch(err => {
                        console.log(err)
                        me.snackbar = true;
                        me.snackResult = "red";
                        me.snackText = '실패'
                    })
            }
        },

        templateExcelItem() {
            var url = this.$vBACKEND_URL + '/item.do?method=itemTemplateDownLoad';
            var obj = {
                uid_company:this.$store.getters.getUidCompany,
            }
            var params = '';
            for(var key in obj) {
            params += '&' + key + '=' + obj[key]
            }
            url += params;

            fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                const excelPath = res.result;
                if(excelPath!=null) {
                    this.snackbar = true;
                    this.snackResult = '#60C5F1';
                    this.snackText = '성공'
                    location.href = this.$vCONTENT_URL + "/excel/" + excelPath
                } else {
                    this.snackbar = true;
                    this.snackResult = 'FFFBE5';
                    this.snackText = '조회된 데이터가 없습니다.'
                }
            })
            .catch(err => {
                console.log(err)
                this.snackbar = true;
                this.snackResult = 'red';
                this.snackText = '실패'
            })
        },

        downloadExcelItem() {
            var url = this.$vBACKEND_URL + '/item.do?method=itemExcelDownLoad';
            var obj = {
                uid_company:this.$store.getters.getUidCompany,
            }
            var params = '';
            for(var key in obj) {
            params += '&' + key + '=' + obj[key]
            }
            url += params;

            fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                const excelPath = res.result;
                if(excelPath!=null) {
                    this.snackbar = true;
                    this.snackResult = '#60C5F1';
                    this.snackText = '성공'
                    location.href = this.$vCONTENT_URL + "/excel/" + excelPath
                } else {
                    this.snackbar = true;
                    this.snackResult = 'FFFBE5';
                    this.snackText = '조회된 데이터가 없습니다.'
                }
            })
            .catch(err => {
                console.log(err)
                this.snackbar = true;
                this.snackResult = 'red';
                this.snackText = '실패'
            })
        },

        uploadExcelLocation() {
            alert('준비중입니다.')
        },

        downloadExcelLocation() {
            var url = this.$vBACKEND_URL + '/stock.do?method=stockTemplateDownLoad';
            var obj = {
                uid_company:this.$store.getters.getUidCompany,
            }
            var params = '';
            for(var key in obj) {
            params += '&' + key + '=' + obj[key]
            }
            url += params;

            fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                const excelPath = res.result;
                if(excelPath!=null) {
                    this.snackbar = true;
                    this.snackResult = '#60C5F1';
                    this.snackText = '성공'
                    location.href = this.$vCONTENT_URL + "/excel/" + excelPath
                } else {
                    this.snackbar = true;
                    this.snackResult = 'FFFBE5';
                    this.snackText = '조회된 데이터가 없습니다.'
                }
            })
            .catch(err => {
                console.log(err)
                this.snackbar = true;
                this.snackResult = 'red';
                this.snackText = '실패'
            })
        },

        excelLocationBarcode() {
            var url = this.$vBACKEND_URL + '/stock.do?method=stockExcelDownLoad';
            var obj = {
                uid_company:this.$store.getters.getUidCompany,
            }
            var params = '';
            for(var key in obj) {
            params += '&' + key + '=' + obj[key]
            }
            url += params;

            fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                const excelPath = res.result;
                if(excelPath!=null) {
                    this.snackbar = true;
                    this.snackResult = '#60C5F1';
                    this.snackText = '성공'
                    location.href = this.$vCONTENT_URL + "/excel/" + excelPath
                } else {
                    this.snackbar = true;
                    this.snackResult = 'FFFBE5';
                    this.snackText = '조회된 데이터가 없습니다.'
                }
            })
            .catch(err => {
                console.log(err)
                this.snackbar = true;
                this.snackResult = 'red';
                this.snackText = '실패'
            })
        }
    }
}
</script>
