<template>
    <v-container id="container">
        <v-toolbar
                    class="mb-1"
                >
                    <v-btn
                        color="primary"
                        dark
                        class="mb-2"
                        style="margin-right: 1%;"
                        @click="search"
                    >검색</v-btn>
                    <v-btn
                        color="cyan lighten-2"
                        dark
                        class="mb-2"
                        style="margin-right: 1%;"
                        @click="add"
                    >추가</v-btn>
                    <v-btn
                        color="green lighten-2"
                        dark
                        class="mb-2"
                        style="margin-right: 1%;"
                        @click="edit"
                    >수정</v-btn>
                    <v-btn
                        color="error"
                        dark
                        class="mb-2"
                        style="margin-right: 1%;"
                        @click="remove"
                    >삭제</v-btn>
                </v-toolbar>

                <v-toolbar
                    class="mb-1"
                    style="width:20%;"
                >
                    <v-text-field
                        v-model="srch_item_code"
                        label="품번"
                    ></v-text-field>
                </v-toolbar>
        <v-data-table
            :headers="columns"
            :items="datas"
            item-key="id"
            class="elevation-1"
            style="width:100%; height:90%; overflow:scroll;"
        >
            <template v-slot:header>
                
            </template>
            <!-- <template v-slot:body.append>
                
            </template> -->
        </v-data-table>
    </v-container>
</template>

<script>

export default {
    name:'ItemView',
    data() {
        return {
            srch_item_code:null,
            srch_item_name:null,
            srch_specification:null,
            datas:[
                { id:1, item_code:'품번1', item_name:'품명1', specification:'규격1', unit_code:'Kg', safe_quan:10 },
                { id:2, item_code:'품번2', item_name:'품명2', specification:'규격2', unit_code:'EA', safe_quan:11 },
                { id:3, item_code:'품번3', item_name:'품명3', specification:'규격3', unit_code:'M', safe_quan:12 },
                { id:4, item_code:'품번4', item_name:'품명4', specification:'규격4', unit_code:'Kg', safe_quan:13 },
                { id:5, item_code:'품번5', item_name:'품명5', specification:'규격5', unit_code:'Kg', safe_quan:14 },
            ],
        }
    },
    computed: {
        columns() {
            return [
                { text: '품번', align: 'start', sortable: false, value: 'item_code' },
                { text: '품명', align: 'start', sortable: false, value: 'item_name' },
                { text: '규격', align: 'start', sortable: false, value: 'specification' },
                { text: '단위', align: 'center', sortable: false, value: 'unit_code' },
                { text: '안전재고', align: 'end', sortable: false, value: 'safe_quan' },
            ]
        }
    },
    mounted() {
        
    },
    components: {

    },
    watch: {

    },
    methods: {
        search() {
            alert('search')
        },
        add() {
            alert('add')
        },
        edit() {
            alert('edit')
        },
        remove() {
            alert('remove')
        },
    }
}
</script>
