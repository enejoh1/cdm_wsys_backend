<template>
  <div>

      <vuetable ref="vuetable"
        :api-mode="false"
        :fields="fields"
        :data="datas"
        pagination-path=""
        :per-page="perPage"
        :multi-sort="multiSort"
        :table-height="tableHeight"
        :css="{sortableIcon: 'grey sort icon',tableClass: 'vuetable ui  selectable unstackable celled table fixed'}"
        @vuetable:pagination-data="onPaginationData"
        @vuetable:initialized="onInitialized"
        @vuetable:loading="showLoader"
        @vuetable:loaded="hideLoader"
        @vuetable:cell-clicked="onCellClicked"
        @vuetable:scrollbar-visible="onScrollbarVisible"
      >
        <!-- <template slot="tableHeader">
          <vuetable-row-header></vuetable-row-header>
          <row-filter
            :visible="filterRowVisible"
            @vuetable:header-event="onRowHeaderEvent"
          ></row-filter>
        </template> -->
      </vuetable>

      <div class="vuetable-pagination ui bottom attached segment grid">
        <vuetable-pagination-info ref="paginationInfo"
        ></vuetable-pagination-info>
        <component :is="paginationComponent" ref="pagination"
          @vuetable-pagination:change-page="onChangePage"
        ></component>
      </div>
    </div>
</template>

<script>
import Vuetable from "vuetable-2";
import VuetablePagination from "vuetable-2/src/components/VuetablePagination";
import VuetablePaginationDropdown from "vuetable-2/src/components/VuetablePaginationDropdown.vue";
import VuetablePaginationInfo from "vuetable-2/src/components/VuetablePaginationInfo.vue";
import VuetableRowHeader from "vuetable-2/src/components/VuetableRowHeader.vue";
import FieldsDef from "./utils/FieldsDef.js";
import MyDetailRow from "./utils/MyDetailRow";
import SettingsModal from "./utils/SettingsModal";
import sweetAlert from "sweetalert2";
import RowFilter from "./utils/RowFilter.vue";
import RowEventHandler from "./utils/RowEventHandler.js";
import VuetableFieldCheckbox from "vuetable-2/src/components/VuetableFieldCheckbox.vue";

export default {
  name: "MyVuetable",

  components: {
    Vuetable,
    VuetablePagination,
    VuetablePaginationDropdown,
    VuetablePaginationInfo,
    VuetableRowHeader,
    RowFilter,
    SettingsModal
  },

  data() {
    return {
      detailRow: MyDetailRow,
      paginationComponent: "vuetable-pagination",
      loading: "",
      tableHeight: "72vh",
      multiSort: true,
      perPage: 10,
      filterRowVisible: true,
      scrollbarVisible: false,
      
        fields: [
            {   
                name: VuetableFieldCheckbox,
                title: "checkbox",
                width: "40px",
                titleClass: "center aligned",
                dataClass: "center aligned",
                togglable: true
            },
            { name:'item_code', title:'품번', width:'15%', titleClass: 'center aligned', dataClass: 'left aligned', },
            { name:'item_name', title:'품명', width:'15%', titleClass: 'center aligned', dataClass: 'left aligned' },
            { name:'specification', title:'규격', width:'25%', titleClass: 'center aligned', dataClass: 'left aligned' },
            { name:'quan', title:'수량', width:'10%', titleClass: 'center aligned', dataClass: 'right aligned' },
            { name:'bin_code', title:'위치정보', width:'10%', titleClass: 'center aligned', dataClass: 'center aligned' },
            { name:'last_in_date', title:'최근입고날짜', width:'25%', titleClass: 'center aligned', dataClass: 'center aligned' },
        ],
        datas:[
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-12' },
            { item_code:'품번2', item_name:'품명2', specification:'규격2', quan:3, bin_code:'A012312', last_in_date:'2021-11-13' },
            { item_code:'품번3', item_name:'품명3', specification:'규격3', quan:4, bin_code:'A012313', last_in_date:'2021-11-14' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번3', item_name:'품명3', specification:'규격3', quan:4, bin_code:'A012313', last_in_date:'2021-11-14' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번3', item_name:'품명3', specification:'규격3', quan:4, bin_code:'A012313', last_in_date:'2021-11-14' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
            { item_code:'품번4', item_name:'품명4', specification:'규격4', quan:5, bin_code:'A012314', last_in_date:'2021-11-15' },
            { item_code:'품번1', item_name:'품명1', specification:'규격1', quan:2, bin_code:'A012311', last_in_date:'2021-11-16' },
        ],
    };
  },

  watch: {
    perPage(newVal, oldVal) {
      this.$nextTick(() => {
        this.$refs.vuetable.refresh();
      });
    },

    paginationComponent(newVal, oldVal) {
      this.$nextTick(() => {
        this.$refs.pagination.setPaginationData(
          this.$refs.vuetable.tablePagination
        );
      });
    }
  },

  methods: {
    onPaginationData(tablePagination) {
      this.$refs.paginationInfo.setPaginationData(tablePagination);
      this.$refs.pagination.setPaginationData(tablePagination);
    },

    onChangePage(page) {
      this.$refs.vuetable.changePage(page);
    },

    onInitialized(fields) {
      this.vuetableFields = fields.filter(field => field.togglable);
    },

    showLoader() {
      this.loading = "loading";
    },

    hideLoader() {
      this.loading = "";
    },

    showSettingsModal() {
      this.$refs.settingsModal.show();
    },

    onCellClicked({ data, field, event }) {
      if (field.name !== this.fieldPrefix + "actions") {
        this.$refs.vuetable.toggleDetailRow(data.id);
      }
    },

    onActionClicked(action, data) {
      sweetAlert(action, data.name);
    },

    onRowHeaderEvent(type, payload) {
      console.log("onRowHeaderEvent:", type, payload);

      let handler = RowEventHandler;

      return typeof handler[type] === "function"
        ? handler[type](this, this.$refs.vuetable, payload)
        : console.log("Unhandled event: ", type, payload);
    },

    onScrollbarVisible(toggle) {
      this.scrollbarVisible = toggle;
    }
  }
};
</script>

<style>
.vuetable button.ui.button {
  padding: 0.5em 0.5em;
  font-weight: 400;
}
.vuetable button.ui.button i.icon {
  margin-right: 0px !important;
}
.ui.grid.toolbar {
  padding-bottom: 10px;
}
</style>
