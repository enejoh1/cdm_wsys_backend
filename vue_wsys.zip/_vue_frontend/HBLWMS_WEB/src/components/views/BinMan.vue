<template>
    <div >

        <v-toolbar style="background:#cad9e5;">
            <v-row>
                <v-btn
                    tile
                    color=""
                    style="margin-right:1%;"
                    @click="getDatas"
                    v-bind:disabled="this.cancelDisabled==false"
                >
                    <v-icon left>
                        mdi-magnify
                    </v-icon>
                    검색
                </v-btn>
                <v-btn
                    hidden
                    tile
                    color="primary"
                    style="margin-right:1%;"
                    @click="dialog_wearing=true"       
                    v-bind:disabled="this.cancelDisabled==false"
                    @mousedown="resetAddForm"
                >
                    <v-icon left>
                        mdi-plus-circle
                    </v-icon>
                    입고
                </v-btn>
                <!-- :disabled="cancelDisabled" -->
                <v-btn
                    hidden
                    tile
                    color="error"
                    style="margin-right:1%;"
                    
                    @click="dialogCancel=true"
                    v-bind:disabled="this.cancelDisabled==true"
                >
                    <v-icon left>
                        mdi-minus-circle
                    </v-icon>
                    입고취소
                </v-btn>
                <v-spacer></v-spacer>
                <v-btn
                    hidden
                    tile
                    color="success"
                    style="margin-right:1%;"
                    @click="wearingExcelUpload"
                >
                    <v-icon left>
                        mdi-upload
                    </v-icon>
                    업로드
                </v-btn>
                <v-btn
                    hidden
                    tile
                    color="primary"
                    style="margin-right:1%;"
                    @click="wearingExcelDownload"
                >
                    <v-icon left>
                        mdi-download
                    </v-icon>
                    입고내역
                </v-btn>
                <v-btn
                    hidden
                    tile
                    color="error"
                    style="margin-right:1%;"
                    @click="wearingExcelTemplate"
                >
                    <v-icon left>
                        mdi-file-excel
                    </v-icon>
                    템플릿
                </v-btn>
            </v-row>
        </v-toolbar>


        <v-toolbar style="background:#cad9e5;">
            <v-toolbar-items style="margin-right:1%; margin-top:3%;">
                <v-text-field
                    hidden
                    v-model="lot_code"
                    id="bin_lotno"
                    label="LOT번호"
                    v-on:lot_code_update="onTextChangne2('lotno', $event)"
                    @change="value => onTextChangne('lotno', value)"
                    @input="onTextChangne2('lotno', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                    ref="lotno_val"
                    clearable
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items style="margin-right:1%; margin-top:3%;">
                <v-text-field
                    v-model="i_code"
                    id="bin-wh_code"
                    label="창고"
                    v-on:i_code_update="onTextChangne2('wh_code', $event)"
                    @change="value => onTextChangne('wh_code', value)"
                    @input="onTextChangne2('wh_code', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                    ref="itemcode_val"
                    clearable
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items style="margin-right:1%; margin-top:3%;">
                <v-text-field
                    id="bin-rack_code"
                    label="rack_code"
                    @change="value => onTextChangne('rack_code', value)"
                    @input="onTextChangne2('rack_code', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                    clearable
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items style="margin-right:1%; margin-top:3%;">
                <v-text-field
                    id="bin-bin-col"
                    label="열"
                    @change="value => onTextChangne('bin_col', value)"
                    @input="onTextChangne2('bin_col', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                    clearable
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items style="margin-right:1%; margin-top:3%;">
                <v-text-field
                    id="bin-bin-row"
                    label="행"
                    @change="value => onTextChangne('bin_row', value)"
                    @input="onTextChangne2('bin_row', $event)"
                    @keyup="getDatas"
                    @keydown="disabledSelectAll"
                    clearable
                ></v-text-field>
            </v-toolbar-items>
            <v-toolbar-items style="margin-right:1%; margin-top:3%;" hidden>
                <v-menu
                    v-model="wearing_date_menu"
                    :close-on-content-click="false"
                    :nudge-right="40"
                    transition="scale-transition"
                    offset-y
                    min-width="auto"
                    hidden
                >
                    <template v-slot:activator="{ on, attrs }" hidden>
                        <v-text-field
                            hidden
                            v-model="date_range"
                            label="입고날짜"
                            readonly
                            v-bind="attrs"
                            v-on="on"
                            :append-outer-icon="'mdi-refresh'"
                            @click:append-outer="refreshDateRange"
                            @mousedown="disabledSelectAll"
                        ></v-text-field>
                    </template>
                    <v-date-picker
                        v-model="start_date"
                        @input="input_start"
                        locale="ko-KR"
                    ></v-date-picker>
                    <v-date-picker
                        v-model="end_date"
                        @input="input_end"
                        locale="ko-KR"
                    ></v-date-picker>
                </v-menu>
            </v-toolbar-items>
        </v-toolbar>
        <v-data-table 
            v-model="selected"
            :headers="headers"
            :items="datas"
            class="elevation-1"
            show-select
            item-key="'row- + id"
            @click:row='view_items'
            height="100%"
            fixed-header
            dense

            :item-class="rowClass"
            :items-per-page="perPage"
            :footer-props="footerProps"
            :page.sync="page"
            :server-items-length="dataCounts"
            :options.sync="options"
            
        >         
        <!--
          <template v-slot:item="{ item }">
            <tr :style="getTableRowStyle(item)">
 
                <td >{{ item.bin_code }}</td>
                <td >{{ item.lotno }}</td>
                <td >{{ item.item_code }}</td>
                <td >{{ item.item_name }}</td>
                <td >{{ item.specification }}</td>
                <td >{{ item.detail_info }}</td>
                <td >{{ item.quan }}</td>
                <td :style="{ color: item.safe_quan > item.quan ? 'red' : '' }">{{ item.safe_quan }}</td>
            </tr>
        </template>
        -->       
        
        <template v-slot:item.safe_quan="{ item }">
            <td :style="{ color: item.safe_quan > item.quan ? 'red' : '' }">{{ item.safe_quan }}</td>
          </template>
        
        </v-data-table>

        <v-overlay :value="overlay">
            <v-progress-circular
                indeterminate
                size="64"
            ></v-progress-circular>
        </v-overlay>

        <v-dialog
            v-model="dialog_wearing"
            width='80%'
            height="45%"
            max-width="1200px"
            style="height: 45%;"
            scrollable      
            @change="load_container"                                                       
            >
            <div style="width:100%; height:100%; display:flex; background:white;">
                <div id="form" style="width:70%; height:650px;">
                    <v-card>
                        <v-card-title>
                            <span class="text-h4">입고</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                    <v-col cols="12">

                                        <v-autocomplete
                                            id="itemsid"
                                            v-model="search_item"
                                            auto-selct-first
                                            autofocus
                                            ref="autoinput"

  
                                            label="검색"
                                            clear-icon="mdi-close-circle"
                                            :append-icon="'mdi-magnify'"
                                            type="text"
                                            :items="searchItemList"
                                            :search-input.sync="searchAdd"
                                            hide-details
                                            item-text="search_name"
                                            item-value="search_name"
                                            return-object
                                            @mousedown="searchAdd_void"
                                            @change="clickAddItemCode" 
                                            @click="searchAdd_void, $refs.add_lotno.focus()"
                                            v-on:keyup.enter="searchAdd_void,$refs.add_lotno.focus()"
                                        ></v-autocomplete>     
                                    </v-col>
                                    <v-col cols="12">
                                        <v-text-field
                                            ref="add_lotno"
                                            v-model="lotno"
                                            label="LOT번호"
                                            v-on:keyup.enter="$refs.quan.focus()"
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            ref="add_item_code"
                                            v-model="add_item_code"
                                            label="품번"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            ref="add_item_name"
                                            v-model="add_item_name"
                                            label="품명"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            ref="add_specification"
                                            v-model="add_specification"
                                            label="규격"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                        <v-text-field
                                            ref="add_detail_info"
                                            v-model="add_detail_info"
                                            label="상세사양"
                                            readonly
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12">
                                        <v-text-field
                                            v-model="add_quan"
                                            label="수량"
                                            required
                                            ref="quan"
                                            v-on:keyup.enter="$refs.btn_add_bin_code.focus()"
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12">
                                        <v-autocomplete
                                            ref="btn_add_bin_code"
                                            v-model="add_bin_code"
                                            label="위치정보"
                                            clear-icon="mdi-close-circle"
                                            :append-icon="'mdi-magnify'"
                                            type="text"
                                            :items="addBinCodes"
                                            :search-input.sync="searchBinAdd"
                                            hide-details
                                            item-text="bin_code"
                                            item-value="bin_code"
                                            return-object
                                            @change="clickAddBinCode"
                                            @click="searchBinAdd_void"
                                            
                                        ></v-autocomplete>
        
                                    </v-col>
                                    <v-col cols="6" align="center">
                                        <v-btn
                                            tile
                                            color="primary"
                                            @click="execUnitWearing"
                                            ref="instockbtn"
                                        >
                                            입고
                                        </v-btn>
                                    </v-col>
                                    <v-col cols="6" align="center">
                                        <v-btn
                                            tile
                                            color="error"
                                            @click="() => dialog_wearing = false"
                                    >   
                                            취소
                                        </v-btn>
                                    </v-col>
                                </v-row>
                            </v-container>
                        </v-card-text>
                    </v-card>
                </div>
                <div id="cards" style="width:30%; height:650px; overflow: scroll;">

                    <v-card 
                        v-for="(card, index) in cards" 
                        :key="index" 
                        style="margin-bottom:1%; background:#c6c6f8;"
                        @click="clickCardBin(card)"    
                    >
                        <v-card-title>{{ card.bin_code }}  - {{ card.lotno }}</v-card-title>
                        <v-card-text>{{ card.quan + ' ' + card.unit_code }}</v-card-text>
                    </v-card>
                </div>
            </div>
        </v-dialog>

        <v-dialog
            v-model="dialogCancel"
            width="500px"
            max-width="500px"
        >
            <v-card style="height:180px;">
                <v-card-title>입고취소</v-card-title>
                <v-card-text>선택하신 항목을 입고취소 하시겠습니까?</v-card-text>
                <v-card-actions style="justify-content: end;">
                    <v-btn
                        color="white"
                        style="backgroundColor:green;"
                        text
                        @click="cancelWearing"
                    >확인</v-btn>
                    <v-btn
                        color="white"
                        style="backgroundColor:red;"
                        text
                        @click="dialogCancel = false"
                    >취소</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>

        <v-snackbar
            v-model="snack"
            :timeout="3000"
            :color="snackColor"
            top
        >
            {{ snackText }}
        </v-snackbar>

        <v-dialog
            v-model="view_bin_items"
            width='80%'
            height="45%"
            max-width="1200px"
            style="height: 45%;"
            scrollable      
                                                       
            >
            <div style="width:100%; height:100%; display:flex; background:white;">
                <div id="form" style="width:100%; height:650px;"
                @click="view_bin_items=false"   
                >
                    <v-card>
                        <v-card-title width='100%'>
                            <span class="text-h5" >입고리스트</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>          
                                    <v-col cols="12" align="left" hidden>    
                                    <v-text-field v-model="view_row_num" label="row" required></v-text-field>         
                                    </v-col>            
                                    <v-col cols="12" align="center">
                                        <v-text-field v-model="view_bin_code" label="bin코드" required></v-text-field>         
                                    </v-col>
                                    <v-col cols="12" align="center">
                                        
                                    </v-col>
                                </v-row>
                            </v-container>
                            <div id="cards2" style="width:30%; height:650px; overflow: scroll;">
                                <v-card 
                                    v-for="(card, index) in cards" 
                                    :key="index" 
                                    style="margin-bottom:1%; background:#c6c6f8;"
                                    @click="clickCardBin(card)"    
                                >
                                    <v-card-title>{{ card.bin_code }}  - {{ card.lotno }}</v-card-title>
                                    <v-card-text>{{ card.quan + ' ' + card.unit_code }}</v-card-text>
                                </v-card>
                            </div>
            
                                </v-card-text>
                    </v-card>
                </div>
                
            </div>
        </v-dialog>

    </div>
</template>

<script>
import axios from 'axios'
import { emit } from 'process';
//@click:append="getDatas"
export default {
  name: "Wearing",
  components: {
    
  },
  data() {
    return {
        autoUpdate: true,
        headers: [
            //{ value:'unique_id', text:'unique_id', width:'20%', align:'start', sortable: true, },
            //{ value:'uid_company', text:'uid_company', width:'20%', align:'start', sortable: true, },
            //{ value:'unique_id_str', text:'unique_id_str', width:'20%', align:'start', sortable: true, },
            //{ value:'wh_code', text:'창고', width:'20%', align:'start', sortable: true, },
            //{ value:'wh_name', text:'wh_name', width:'20%', align:'start', sortable: true, },
            //{ value:'uid_rack', text:'uid_rack', width:'20%', align:'start', sortable: true, },
            { value:'bin_code', text:'bin 코드', width:'10%', align:'left', sortable: true, },//##DBG lotno 추가
            //{ value:'rack_code', text:'동', width:'10%', align:'start', sortable: true, },
            //{ value:'rack_name', text:'rack_name', width:'20%', align:'start', sortable: true, },
            //{ value:'bin_name', text:'bin name', width:'15%', align:'start', sortable: true, },
            //{ value:'bin_col', text:'열', width:'5%', align:'start', sortable: true, },
            //{ value:'bin_row', text:'행', width:'5%', align:'start', sortable: true,},
            { value:'lotno', text:'LOT-NO', width:'10%', align:'start', sortable: true,},
            { value:'item_code', text:'품목코드', width:'10%', align:'start', sortable: true,},
            { value:'item_name', text:'품목명', width:'15%', align:'start', sortable: true,},
            { value:'specification', text:'사양', width:'15%', align:'start', sortable: true,},
            { value:'detail_info', text:'상세정보', width:'15%', align:'start', sortable: true,},
            { value:'quan',      text:'재고',     width:'10%', align:'end', sortable: true,},
            { value:'safe_quan', text:'안전재고', width:'15%', align:'start', sortable: true,},
            //{ value:'chagge_date', text:'변경일자', width:'10%', align:'start', sortable: true, },
            //{ value:'changer', text:'changer', width:'20%', align:'start', sortable: true, },
            //{ value:'changer_uid', text:'changer_uid', width:'20%', align:'start', sortable: true, },
            //{ value:'create_date', text:'등록일자', width:'10%', align:'center', sortable: true, },
            //{ value:'creater', text:'creater', width:'20%', align:'start', sortable: true, },
            //{ value:'creator_uid', text:'creator_uid', width:'20%', align:'start', sortable: true, },
            //{ value:'del_yn', text:'del_yn', width:'20%', align:'start', sortable: true, },
            //{ value:'id', text:'id', width:'20%', align:'start', sortable: true, },
            //{ value:'key', text:'key', width:'20%', align:'start', sortable: true, },
            //{ value:'rownum', text:'rownum', width:'20%', align:'start', sortable: true, },
            //{ value:'last_in_date', text:'최근입고날짜', width:'25%', align:'start', sortable: true, },
        ],
        i_code:'',  //입고완료시 입고 품번으로 입고 리스트만을 조회하기위한 변수
        lot_code:'',
        datas:[],
        dataCounts:0,
        perPage:100,
        page:1,
        footerProps: { 'items-per-page-options': [100, -1] },
        options:{},
        params:{},

        lotno:null,

        sortBy: ['bin_row','bin_col'],
        sortDesc: [true,false],

        overlay: false,
        dialog_wearing:false,
        dialogCancel:false,

        search_item:null,///###DBG
        value:'TP',///###DBG
        searchInput:'TP',///###DBG
        item_code:'TP',///###DBG

        orderBy:null,
        order_desc:null,

        searchAdd:null,
        searchItemList:[], //['XP','XC'],///###DBG
 
        searchBinAdd:null,
        addBinCodes:[],

        add_item_uid:null,
        add_item_code:null,
        add_item_name:null,
        add_specification:null,
        add_detail_info:null,
        add_quan:null,
        add_bin_code:null,

        cards: [],
        selected:[],
        selectedCard:null,
        selectedItem:null,
        
        snack:false,
        snackColor:'',
        snackText:'',

        wearing_date_menu:false,
        date_range:'',
        start_date:'',
        end_date:'',

        inputStart:false,
        inputEnd:false,

        item_code_b:'',///##DBG
        view_bin_items:null,
        view_row_num:null,
        view_bin_code:null,
        row_color:0,
        row_bin:null,
        colorMap: {}, // 배경색을 매핑할 객체

        cancelDisabled:true
    };
  },

  mounted() {

    this.init();

    console.log("---------------- mounted -----------------")
    this.$nextTick(() => {
      console.log(this.$refs.autoInput);
    });
  },

  watch: {

      selected() {
        if(this.selected.length>0) {
            this.cancelDisabled = false
        } else {
            this.cancelDisabled = true
        }
      },
      getContextPath(){
            var hostIndex = location.href.indexOf( location.host ) + location.host.length;
            var contextPath = location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
            return contextPath;
      },
      searchAdd(val) {
        console.log("-----------------searchAdd-------------");
        if(val != null ) {
            console.log(val);
        }

        if(val == null || val.length < 1) return;
            console.log("----------searchAdd.1--------------")
            var sresult='';
            if(val!='') {
                const str = val;
                const result = str.split("/");
                console.log(result);
                sresult = result[0];        // 품목에대한 재고 정보를 나타나게한다.
            }
            else{
                sresult = '';
            }

        console.log("----------searchAdd.2--------------")
        console.log(val);

        if(val == null || val.length < 1) return;

            var url = this.$vBACKEND_URL + '/item.do?method=readBin'; //##DBG :  https://api.hblwms.co.kr/item.do?method=readItem
            var pObj = {
                uid_company:this.$store.getters.getUidCompany,
                search_item:sresult    
                // item_code:val
            }
            var params = '';
            for(var key in pObj) {
                params += '&' + key + '=' + pObj[key]
            }

            console.log("----------searchAdd.3--------------")
            url += params;
            console.log(val);
            console.log(url);

            fetch(url)
                .then(res => res.clone().json())
                .then(res => {
                    console.log("----------searchAdd.fetch--------------")
                    this.searchItemList = res.result
                    console.log(res)
                    console.log(res.result)
                    console.log(res.result[0].unique_id);
                     console.log(res.result[0].unique_id)
                    this.item_uids = res.result[0].unique_id  //##DBG 추가 : item uids가 한템포 늦게 로딩되는 문제로 입고가 안되서 추가
                    this.clickAddItemCode(res.result[0])       //##DBG 추가 : 선택한 행의 입고창이 열릴때, 재고 리스트가 나타나지않는문제 수정
                })
                .catch(err => {
                    console.log(err)
                })
                console.log("----------searchAdd.end--------------")
      },
      searchBinAdd(val) {
          if(val == null || val.length < 1) return;

        var url = this.$vBACKEND_URL + '/stock.do?method=readBin';  //##DBG :  https://api.hblwms.co.kr/stock.do?method=readBin
        var pObj = {
            uid_company:this.$store.getters.getUidCompany,
            bin_code:val
        }
        var params = '';
        for(var key in pObj) {
            params += '&' + key + '=' + pObj[key]
        }

        url += params;

        fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                this.addBinCodes = res.result
            })
            .catch(err => {
                console.log(err)
            })
      },

      wearing_date_menu() {
          if(this.wearing_date_menu) {
              this.inputStart = false;
              this.inputEnd = false;
          }
      },
      
     options(val) {
        var curPage = val.page;
        var itemsPerPage = val.itemsPerPage;
        if(itemsPerPage!=null && itemsPerPage==-1) {
            itemsPerPage = 100000000;
        }
        this.page = curPage;
        this.perPage = itemsPerPage;

        //##DBG 추가 정렬
        if(val.sortBy[0]){
            this.orderBy = "&orderBy=" + val.sortBy[0];
            this.order_Desc = "&isAsc=" +  val.sortDesc[0];
        }
        else{
            this.orderBy=null;//"&orderBy=history.hid_date";
            this.order_Desc=null;//"&isAsc=false";
        }

        this.getDatas();
     }
  },
  created(){
    this.groupDataByBincode();
  },

  methods: {
    init() {
        this.getDatas()
    },
    onInput(item){
        console.log("--------------- onInput------------")
        console.log("on input:   ", item);
    },


    sortFunction(){
        console.log("-------------------------------------<>");
    },

    click_ColHeader(val){
    console.log("===================================");
    console.log(val);
    },


    rowClass(item) {
        // let quan = item.quan
        // let safe_quan = item.safe_quan
        // if(safe_quan!=null && safe_quan>0) {
        //     if(safe_quan>quan) {
        //         return 'red-row'
        //     }
        // }
        if(item.quan==0) {
            return 'gray-row';
        }
        else{
            // console.log( this.row_bin + ' : ' + item.bin_code + ' : ' + this.row_color );
            // if(this.row_bin != item.bin_code){
            //     this.row_bin = item.bin_code;
            //     if(this.row_color==0){
            //         this.row_color=1;
            //     }
            //     else{
            //         this.row_color=0;
            //     }
            // }
            // if(this.row_color==0){
            //     return 0;
            // }
            // else{
            //     return 'orange-row';
            // }            
            return 0;
        }
    },

    groupDataByBincode() {
      this.datas.forEach(contact => {
        const bincode = contact.bin_code;
        if (!this.colorMap[bincode]) {
          // 지역명이 새로운 경우에만 배경색 매핑
          this.colorMap[bincode] = this.getRandomColor();
        }
      });
    },
    getTableRowStyle(item) {
      const bincode = item.bin_code;
      const backgroundColor = this.colorMap[bincode] || '';
      return `background-color: ${backgroundColor};`;
    },
    getRandomColor() {
      // 랜덤 배경색 생성을 위한 코드
      // 이 예시에서는 간단하게 랜덤한 HEX 컬러값을 반환합니다.
      return '#' + Math.floor(Math.random() * 16777215).toString(16);
    },

    getAddCard2(o) {
        // if(this.add_item_code == null || this.add_item_code.length<1) return;
        console.log("-------------- getAddCard2 -------------");
        if(o==null || o.length<1) return;

        var url = this.$vBACKEND_URL + '/stock.do?method=readLocationByUidItem';    //##DBG :  https://api.hblwms.co.kr/stock.do?method=readLocationByUidItem 
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
            uid_item:this.add_item_uid, 
            //##DBG 추가 20230327_1 : uid_item:this.$store.getters.getUidItem//this.add_item_uid // ##DDDBG itemUid를 이전 값을 가져오는 문제로 commit()을 추가하야, 수정
        }
        console.log(obj);

        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' +  obj[key] 
        }
        url += params;
        
        console.log(url);

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const cards = res.result;
            this.cards = cards;
        })
        .catch(err => {
            console.log(err)
        })
    },

    
    view_items(record, row){
        this.view_bin_items=true;
        console.log(row);
        this.view_row_num = row.index;
        this.view_bin_code = row.item.bin_code;
        
        console.log(record);
        var o=record;
         
        console.log(o.unique_id);
        // console.log(o.unique_id);
        // this.selectedItem = o;
        // this.add_item_uid = o.unique_id
        // this.add_item_code = o.item_code
        // this.add_item_name = o.item_name
        // this.add_specification = o.specification
        // this.add_detail_info = o.detail_info

         this.getAddCard2(o);

    },
   
//##DBG 추가 :  item검색장에서 마우스 클릭시 전체리스트목록 가져와서 보여줌-----------
    searchAdd_void() {
        console.log("-----------------searchAdd_void-------------");

        var url = this.$vBACKEND_URL + '/item.do?method=readBin'; //##DBG :  https://api.hblwms.co.kr/item.do?method=readItem
        var pObj = {
            uid_company:this.$store.getters.getUidCompany,
            search_item:''
            // item_code:val
        }
        var params = '';
        for(var key in pObj) {
            params += '&' + key + '=' + pObj[key]
        }

        url += params;
        console.log(url);

        fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                this.searchItemList = res.result
                console.log(res.result)
                //this.getAddCard(res)                        //##DBG 추가 : item uids가 한템포 늦게 로딩되는 문제로 입고가 안되서 추가(unique_id 잘못됨값)
                console.log(res.result[0].unique_id)
                //this.item_uids = res.result[0].unique_id  //##DBG 추가 : item uids가 한템포 늦게 로딩되는 문제로 입고가 안되서 추가
                //this.clickAddItemCode(res.result[0])       //##DBG 추가 : 선택한 행의 입고창이 열릴때, 재고 리스트가 나타나지않는문제 수정//this.clickAddItemCode2(res.result[0])       //##DBG 추가 : 선택한 행의 입고창이 열릴때, 재고 리스트가 나타나지않는문제 수정
            })
            .catch(err => {
                console.log(err)
            })
    },

    //##DBG 추가 :  창고위치 검색장에서 마우스 클릭시 전체리스트목록 가져와서 보여줌-----------
    searchBinAdd_void() {
        console.log("-----------------searchBinAdd_void-------------");
        var url = this.$vBACKEND_URL + '/stock.do?method=readBin';  //##DBG :  https://api.hblwms.co.kr/stock.do?method=readBin
        var pObj = {
            uid_company:this.$store.getters.getUidCompany,
            bin_code:''
        }
        var params = '';
        for(var key in pObj) {
            params += '&' + key + '=' + pObj[key]
        }

        url += params;

        fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                this.addBinCodes = res.result
            })
            .catch(err => {
                console.log(err)
            })
    },

   
    getDatas() {
        var url = this.$vBACKEND_URL + '/stock.do?method=readBinMan';  //##DBG :  https://api.hblwms.co.kr/stock.do?method=readLocationHistory
        var start = (this.page-1) * this.perPage;
        var limit = this.perPage;
        var obj = {
          uid_company:this.$store.getters.getUidCompany,
          start:start,
          limit:limit,
          //gubun:'IN',
          apiType:'ALL'
          //orderBy:'history.his_date desc
        }


        var params = '';
        for(var key in obj) {
          params += '&' + key + '=' + obj[key]
        }

        console.log('---------------6-0-----------------------')
        console.log(params)

        if(this.params!=null) {
            for(var k in this.params) {
                params += '&' + k + '=' + this.params[k]
                console.log(k + '=' + this.params[k]);
            }
        }
        //url=url+'&bin_code=HA140805';
        //url=url+'&bin_code=HA';
        url += params;
        console.log(params);
        this.order_Desc='';
        if(this.orderBy != null && this.orderBy != 'undifined'){
            url += this.orderBy;//"&orderBy=user_name";
            url += this.order_Desc;//"&isAsc=true";
        }
        else{
            url += this.orderBy="&orderBy=bin.bin_row ASC , bin.bin_col asc, item.item_code ASC, location.last_in_date";
        }

        console.log('---------------6-1-----------------------')
        console.log(params)

        console.log('---------------6-----------------------')
        console.log(url)

        this.item_code_b = url;

        console.log('---------------7-----------------------')
        fetch(url)
          .then(res => res.clone().json())
          .then(res => {
              const datas = res.result;
              const count = res.count;
              this.datas = datas;
              this.dataCounts = count;
              console.log(res.result[0]);
          })
          .catch(err => {console.log(err)})
          .finally(() => {
            this.dialog = false;
          })
          console.log('---------------8-----------------------')
    },
    


    //##DBG 추가 : 그리드의 체커박스 체커 (기존에는 행을 클릭시 체커박스 체커하도록 수정되었음)
    onClickCol(record, row) {
        const isSelected = row.isSelected;
        if(isSelected) {
            row.select(false);
        } else {
            row.select(true);
        }
    },

    search_1() {
      const query = this.$refs.add_bin_code.internalValue;
      if (query) {
        this.$refs.autocomplete.search = query;
      }
    },

    //##DBG 추가 : 그리드의 행을 클릭시 입고창을띄우고 클릭한 item정보를 입고창에 자동 로딩
    onClickRow(record, row) {
        this.resetAddForm();
        console.log("------------onClickRow----------")
        console.log(row.item);
        console.log(row.item.item_code);
        this.dialog_wearing=true;

        setTimeout(() => {
          this.searchAdd = row.item.item_code;//자동항목 셀렉트박스에 검색용 item 코드 입력
        }, 500)

        //this.search_1();

        console.log("------------onClickRow 2----------")
        this.searchAdd =row.item.item_code;//자동항목 셀렉트박스에 검색용 item 코드 입력
        //this.search_item = row.item.item_code;
        console.log(this.search_item);

        if(document.getElementById('itemsid') != null){
            console.log(document.getElementById('itemsid'));
        }

        console.log(this.searchAdd);

        if(this.$refs.autoinput != null){
            console.log("------------onClickRow 3----------")
            console.log(this.$refs.autoinput);

            if(this.$refs.autoinput.items[0] !=null){
                console.log(".>");
                console.log(this.$refs.autoinput.items[0].unique_id);            
                this.add_item_uid = this.$refs.autoinput.items[0].unique_id;
            }
            else{
                console.log(".>");
                console.log(this.$refs.autoinput._props.value);
                console.log(this.$refs.autoinput._props.value.unique_id);            
                this.add_item_uid = this.$refs.autoinput._props.value.unique_id;
            }
        }

        this.lotno = row.item.lotno;
        this.uid_company = this.$store.getters.getUidCompany;
        this.add_item_code = row.item.item_code;
        this.add_item_name = row.item.item_name;
        this.add_specification = row.item.specification;
        this.add_detail_info = row.item.detail_info        
        this.add_quan = 1;

        setTimeout(() => {
          this.searchAdd = row.item.item_code;//자동항목 셀렉트박스에 검색용 item 코드 입력
        }, 500)

    },

    //##DBG 추가
    disabledSelectAll(){
        console.log("------------diabledSelectAll-------------");
        
        if(this.$refs.dataTable!='undefined' && this.$refs.dataTable.selection){            
            console.log(this.$refs.dataTable);
            const selectedItems = this.$refs.dataTable.selection;
            console.log(selectedItems);

            for(var key in selectedItems) {
                console.log(key);
                console.log(selectedItems[key]);
                selectedItems[key] = false;
                key = null;
            }
            this.selected = [];
        }
    },

    onTextChangne(key, val) {
        console.log('==onTextChangne', key)
        console.log('==onTextChangne val', val)

        //t = this.params[key];
        console.log(this.params);
        if(val==null || val.length<1) {
            this.params[key] = '';
        }else {
            this.params[key]="";
            this.params[key] = val;
            //this.params[key] = t + val.key;
        }

        // alert(document.getElementById('wearing-item_code').value)
    },

    //##DBG 추가 : 상품 등을 입력시 그리드에 해당상품의 입고내역이 자동 조회되도록
    onTextChangne2(key, val) {
        console.log('==onTextChangne', key)
        console.log('==onTextChangne val', val)
        
        //t = this.params[key];
        console.log(this.params);
        if(val==null || val.length<1) {
            this.params[key] = '';
        }else {
            this.params[key]="";
            this.params[key] = val;
            //this.params[key] = t + val.key;
        }

        // alert(document.getElementById('wearing-item_code').value)
    },

    findIndex (target) {
      return [].findIndex.call(this.elements, e => e === target)
    },
    moveFocus (index) {
      if (this.elements[index]) {
        this.elements[index].focus()
      }
    },
    moveNext (event) {
      const index = this.findIndex(event.target)
      this.moveFocus(index + 1)
    },
    movePrev (event) {
      const index = this.findIndex(event.target)
      this.moveFocus(index - 1)
    },
    next(e) {
      e.target?.nextSibling?.focus();
    },

    wearingExcelUpload() {
        let input = document.createElement('input')

        input.id = 'excel'
        input.type = 'file'
        input.accept = 'application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        input.multiple = true

        input.click();

        var url = this.$vBACKEND_URL + '/template.do?method=execWearingExcel'   //##DBG :  https://api.hblwms.co.kr/template.do?method=execWearingExcel
        var me = this

        // Event
        input.onchange = function() {
            me.overlay = true
            const formData = new FormData()
            formData.append('file', this.files[0])
            formData.append('uid_company', me.$store.getters.getUidCompany)
            formData.append('user_uid', me.$store.getters.getUserUid)
            formData.append('user_id', me.$store.getters.getUserId)
            formData.append('user_name', me.$store.getters.getUserName)

            axios.post(url, formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then(res => {
                        console.log(res)
                        me.snack = true;
                        me.snackColor = '#60C5F1';
                        me.snackText = '성공'

                        me.getDatas();
                    }).catch(err => {
                        console.log(err)
                        me.snack = true;
                        me.snackColor = "red";
                        me.snackText = '실패'
                    }).finally(() => {
                        me.overlay = false
                    })
        }
    },

    wearingExcelDownload() {
        this.overlay = true

        var url = this.$vBACKEND_URL + '/stock.do?method=readLocationHistory';  //##DBG :  https://api.hblwms.co.kr/stock.do?method=readLocationHistory
        var obj = {
          uid_company:this.$store.getters.getUidCompany,
        //   start:start,
        //   limit:limit,
          gubun:'IN',
          apiType:'ALL',
          orderBy:'history.his_date desc',
          command:'EXCEL'
        }

        var params = '';
        for(var key in obj) {
          params += '&' + key + '=' + obj[key]
        }
        if(this.params!=null) {
            for(var k in this.params) {
                params += '&' + k + '=' + this.params[k]
            }
        }
        url += params;

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const excelPath = res.result;
            console.log('==excelPath', excelPath)
            if(excelPath!=null) {
                // this.snack = true;
                // this.snackColor = '#60C5F1';
                // this.snackText = '성공'
                location.href = this.$vCONTENT_URL + "/excel/" + excelPath  //##DBG :  https://api.hblwms.co.kr/excel/  + excelPath  
            } else {
                // this.snack = true;
                // this.snackColor = 'FFFBE5';
                // this.snackText = '조회된 데이터가 없습니다.'
            }
            this.overlay = false
        })
        .catch(err => {
            console.log(err)
            this.snack = true;
            this.snackColor = 'red';
            this.snackText = '실패'
            this.overlay = false
        })
        .finally(() => this.overlay = false)
    },

    wearingExcelTemplate() {
        this.overlay = true
        var url = this.$vBACKEND_URL + '/template.do?method=wearingExcelTemplateDown';  //##DBG :  https://api.hblwms.co.kr/template.do?method=wearingExcelTemplateDown
        // var url = this.$vBACKEND_URL + '/template.do?method=stockTemplateDownLoad';
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
        }
        var params = '';
        for(var key in obj) {
        params += '&' + key + '=' + obj[key]
        }
        url += params;

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const excelPath = res.result;
            console.log('==excelPath', excelPath)
            if(excelPath!=null) {
                // this.snack = true;
                // this.snackColor = '#60C5F1';
                // this.snackText = '성공'
                location.href = this.$vCONTENT_URL + "/excel/" + excelPath  //##DBG :  https://api.hblwms.co.kr/excel/  + excelPath  
            } else {
                // this.snack = true;
                // this.snackColor = 'FFFBE5';
                // this.snackText = '조회된 데이터가 없습니다.'
            }
            this.overlay = false
        })
        .catch(err => {
            console.log(err)
            this.snack = true;
            this.snackColor = 'red';
            this.snackText = '실패'
            this.overlay = false
        })
        .finally(() => this.overlay = false)
    },

    clickCardBin(card) {
        // this.selectedCard = card;
        // this.add_bin_code = card.bin_code;

        this.searchBinAddFn(card.bin_code)
    },

    searchBinAddFn(val) {
        if(val == null || val.length < 1) return;

        var url = this.$vBACKEND_URL + '/stock.do?method=readBinMan';  //##DBG :  https://api.hblwms.co.kr/stock.do?method=readBin 
        var pObj = {
            uid_company:this.$store.getters.getUidCompany,
            bin_code:val
        }
        var params = '';
        for(var key in pObj) {
            params += '&' + key + '=' + pObj[key]
        }

        url += params;

        fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                this.addBinCodes = res.result
                this.add_bin_code = this.addBinCodes[0].bin_code
            })
            .catch(err => {
                console.log(err)
            })
    },

    clickAddItemCode(o) {
        console.log("------------ clickAddItemCode -----------");
        console.log(o);
        if(o!=null) {
            console.log(o.item_code);
            console.log(o.unique_id);
            this.selectedItem = o;
            this.add_item_uid = o.unique_id
            this.add_item_code = o.item_code
            this.add_item_name = o.item_name
            this.add_specification = o.specification
            this.add_detail_info = o.detail_info

            this.getAddCard(o);
        }
    },

    load_container(){
        var url;

        console.log('-----4-----');
        console.log(this.$store.getters.item_code);
        console.log(this.$mount.getters.itemText);
        // if(this.params!=null) {
        //     if(this.params!=null){
        //         for(var k in this.params) {
        //             params += '&' + k + '=' + this.params[k]
        //             console.log(k + '=' + this.params[k]);
        //         }
        //     }
        // }
        // url += params;
        // console.log(url);
    },

    clickAddBinCode(o) {
        if(o!=null) {
            this.add_bin_code = o.bin_code
        }
    },

    getAddCard(o) {
        // if(this.add_item_code == null || this.add_item_code.length<1) return;
        console.log("-------------- getAddCard -------------");
        if(o==null || o.length<1) return;

        var url = this.$vBACKEND_URL + '/stock.do?method=readLocationByUidItem';    //##DBG :  https://api.hblwms.co.kr/stock.do?method=readLocationByUidItem 
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
            uid_item:this.add_item_uid, 
            //##DBG 추가 20230327_1 : uid_item:this.$store.getters.getUidItem//this.add_item_uid // ##DDDBG itemUid를 이전 값을 가져오는 문제로 commit()을 추가하야, 수정
        }
        console.log(obj);

        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' +  obj[key] 
        }
        url += params;
        
        console.log(url);

        fetch(url)
        .then(res => res.clone().json())
        .then(res => {
            const cards = res.result;
            this.cards = cards;
        })
        .catch(err => {
            console.log(err)
        })
    },

    execUnitWearing() {
        if(this.lotno==null) {
            this.snack = true;
            this.snackColor = "red";
            this.snackText = 'LOT번호를 확인해주세요'
            return;
        }
        if(this.add_item_code==null) {
            this.snack = true;
            this.snackColor = "red";
            this.snackText = '품번을 확인해주세요'
            return;
        }
        if(this.add_bin_code==null) {
            this.snack = true;
            this.snackColor = "red";
            this.snackText = '위치정보를 확인해주세요'
            return;
        }
        if(this.add_quan==null) {
            this.snack = true;
            this.snackColor = "red";
            this.snackText = '수량을 확인해주세요'
            return;
        }

        var url = this.$vBACKEND_URL + '/stock.do?method=execWearingBinCode';   //##DBG :  https://api.hblwms.co.kr/stock.do?method=execWearingBinCode
        var obj = {
            set_lotno:this.lotno,
            uid_company:this.$store.getters.getUidCompany,
            user_uid:this.$store.getters.getUserUid,
            user_id:this.$store.getters.getUserId,
            user_name:this.$store.getters.getUserName,
            item_uids:this.add_item_uid,
            item_quans:this.add_quan,
            bin_code:this.add_bin_code
            // bin_uid:this.selectedCard.uid_bin
        }
        console.log("add_bin_code:");
        console.log(this.add_bin_code);
        obj.item_uids = this.item_uids; //##DBG 추가 : item uids가 한템포 늦게 로딩되는 문제로 입고가 안되서 추가

        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' + obj[key]
        }
        url += params;

        console.log("--------- execUnitWearing ----------");
        console.log(url);

        fetch(url)
            .then(res => res.clone().json())
            .then(res => {
                let result = res.result
                if(result) {
                    this.snack = true;
                    this.snackColor = '#60C5F1';
                    this.snackText = '입고 성공'
                } else {
                    this.snack = true;
                    this.snackColor = "red";
                    this.snackText = '위치정보를 확인해주세요'
                }

                this.getDatas()
            })
            .catch(err => {
                console.log(err)
            })
            .finally(() => this.resetAddForm())
            //##DBG 추가 : 입고된 상품코드로 입고리스트 조회되도록 동작
            this.item_code =this.add_item_code;
            console.log(this.add_item_code);
            this.i_code = this.add_item_code;
            this.$emit('i_code_update');
            this.onTextChangne('item_code', this.add_item_code)
    },

    resetAddForm() {
        this.lotno = null;
        this.add_item_uid = null
        this.search_item = null
        this.add_item_code = null
        this.add_item_name = null
        this.add_specification = null
        this.add_detail_info = null
        this.add_quan = null
        this.add_bin_code = null
        this.cards = null
        this.selectedCard = null
        this.selectedItem = null
        this.cards = [];
    },

    input_start() {
        if(this.inputEnd) {
            this.date_range = this.start_date + " ~ " + this.end_date;
            this.wearing_date_menu = false;
            this.setDateRangeParam();
        }
        this.inputStart = true;
    },

    input_end() {
        if(this.inputStart) {
            this.date_range = this.start_date + " ~ " + this.end_date;
            this.wearing_date_menu = false;
            this.setDateRangeParam();
        }
        this.inputEnd = true;
    },

    setDateRangeParam() {
        if(this.start_date!=null && this.start_date.length>0 &&
            this.end_date!=null && this.end_date.length>0) {
            this.params['his_s_date'] = this.start_date;
            this.params['his_e_date'] = this.end_date;
        }
    },

    refreshDateRange() {
        this.start_date = '';
        this.end_date = '';
        this.date_range = '';
        this.params['his_s_date'] = '';
        this.params['his_e_date'] = '';
    },

    cancelWearing() {
        this.overlay = true

        var uids = [];
        for(var i=0; i<this.selected.length; i++) {
            const select = this.selected[i]
            const uid = select.id;
            uids.push(uid)
        }

        var url = this.$vBACKEND_URL + '/stock.do?method=cancelInOut'   //##DBG : https://api.hblwms.co.kr/stock.do?method=cancelInOut
        var obj = {
            uid_company:this.$store.getters.getUidCompany,
            user_uid:this.$store.getters.getUserUid,
            user_id:this.$store.getters.getUserId,
            user_name:this.$store.getters.getUserName,
        }
        var params = '';
        for(var key in obj) {
            params += '&' + key + '=' + obj[key]
        }
        params += '&' + 'unique_id_list=' + uids
        url += params

        fetch(url)
        // .then(res => res.clone().json())
        .then(res => {
            this.snack = true;
            this.snackColor = 'green';
            this.snackText = '성공'

            this.getDatas()
        })
        .catch(err => {
            console.log(err)
            this.snack = true;
            this.snackColor = 'red';
            this.snackText = '실패'
        })
        .finally(() => {
            this.dialogCancel = false
            this.overlay = false
            this.cancelDisabled = true
        })

    },
  }
};
</script>

<style>
.v-data-table__wrapper {
    height:72vh !important;
}
.v-card {
    white-space: nowrap;
  }
/* .v-dialog {
    height:50% !important;
    overflow: hidden;
} */
/*
.v-btn:hover {
    transform: scale(1.05);
  }
  */
.red-col {
    color: rgb(0, 0, 0);
    background-color: rgb(200, 0, 0);
}  
.red-row {
    color: rgb(0, 0, 0);
    background-color: rgb(200, 0, 0);
}  
.orange-row {
    color: rgb(0, 0, 0);
    background-color: rgb(245, 148, 58);
}  
.gray-row {
    color: rgb(0, 0, 0);
    background-color: rgb(240, 240, 240);
}  
</style>